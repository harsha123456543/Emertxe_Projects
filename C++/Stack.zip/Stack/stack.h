/*----------------------------------------------------------------
 * FILE:        stack.h
 * AUTHOR:      Harsha S
 * PURPOSE:     Contains all the function prototypes
 * DATE:        October 31, 2025
 -----------------------------------------------------------------*/

#ifndef STACK_H
#define STACK_H

#include <iostream>

using namespace std;

//Linked List
class ListNode
{
	//value
	int val;

	//Next node pointer
	ListNode *next;

	public:

	//Constructor
	ListNode(int val , ListNode *temp);

	//Next node getter function
	ListNode *get_next();

	//Value getter function
	int get_val();
};

//Stack
class stack
{

	//Top pointer
	ListNode *top;

	public:

	//Constructor
        stack();

	//Multi value constructor
	template <typename ...Args>
	stack(Args... vals)
        {
                top = nullptr;

                (push(vals), ...);
        }

	//Push operation
	void push(int val);

	//Pop operation
	void pop();

	//Peek operation
	int peek();

	//Isempty operation
	int isempty();

	//Display operation
	void display();

};

#endif
