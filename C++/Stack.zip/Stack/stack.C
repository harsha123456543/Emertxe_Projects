/*----------------------------------------------------------------
 * FILE:        stack.C
 * AUTHOR:      Harsha S
 * PURPOSE:     Contains all the function definitions
 * DATE:        October 31, 2025
 -----------------------------------------------------------------*/

#include "stack.h"

//Linked List class constructor
ListNode :: ListNode(int val , ListNode *temp)
	{
        	this->val = val;
        	next = temp;
	}

//Next node pointer getter function
ListNode *ListNode :: get_next()
	{
		return next;
	}

//Value getter function
int ListNode :: get_val()
	{
		return val;
	}

//Stack class constructor
stack :: stack()
        {
                top = nullptr;
        }

//function to check if stack is empty
int stack :: isempty()
        {

                if(top == NULL)
                        return 1;

                return 0;

        }

//function to push value into stack
void stack :: push(int val)
        {
                top = new ListNode(val,top);
        }

//function to pop value out of stack
void stack :: pop()
        {

		if(isempty())
		{
			cout << "\nStack is empty Cannot Pop" << endl;
			return;
		}

                ListNode *temp = top;
                top = top->get_next();

		cout << endl << temp->get_val() << " Popped successfully" << endl;
                delete temp;
		return;

        }

//function to display top value
int stack :: peek()
        {

                if(top != NULL)
                {
                        return top->get_val();
                }

		cout << "\nStack is empty"<<endl;
                return -1;
        }

//function to display entire stack values
void stack :: display()
        {

		if(isempty())
		{
			cout << "\nStack is empty" << endl;
			return ;
		}

                ListNode *temp = top;

		cout << endl;

                while(temp)
                {

                        cout << temp->get_val() << ' ';
                        temp = temp->get_next();
                }

                cout << endl;
        }

