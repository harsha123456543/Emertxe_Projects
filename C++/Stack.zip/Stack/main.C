/*----------------------------------------------------------------
 * FILE:        main.C
 * AUTHOR:      Harsha S
 * PURPOSE:     Controls all Operations
 * DATE:        October 31, 2025
 -----------------------------------------------------------------*/

#include <iostream>
#include "stack.h"

//Main Function to control all operations
int main()
{

	//Creating a stack of 4 values
	stack stk(1 , 2, 3 , 4);

	int op , val;

	while(1)
	{

		//display allowed operations
		cout << "\n1. Push\n2. Pop\n3. Peek\n4. isempty\n5. display\n\n";

		cin >> op;

		//Perform Selected operation
		switch(op)
		{
			case 1 : 	//Push operation
					cout << "Enter the value to push : ";
				 	cin >> val;
					stk.push(val);
					break;

			case 2 :	//Pop operation
					stk.pop();
					break;

			case 3 :	//Peek operation
					cout << stk.peek();
					break;

			case 4 :	//isempty operation
					if(stk.isempty())
						cout << "Stack is empty"<<endl;
					else
						cout << "Stack not empty"<<endl;
					break;

			case 5 : 	//Display operation
					stk.display();
					break;

			default :	//Invalid command
					cout << "Invalid Operation"<<endl;
					break;
		}

	}


	return 0;


}

