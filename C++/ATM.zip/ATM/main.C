
/*----------------------------------------------------------------
 * FILE:        main.C
 * AUTHOR:      Harsha S
 * PURPOSE:     Controls all operations
 * DATE:        November 1 ,2025
 -----------------------------------------------------------------*/

#include "ATM.h"

//Main function to control all operations
int main()
{

	int op , act , i , log = 1;

	atm atm;

	while(1)
	{
		log = 1;

		//Valid operations
		cout << "\n\n------- Main Menu -------";
		cout << "\n1. Login\n2. Register\n3. Admin Login\n4. Exit\n";
		cout << "---------------------------" << endl << endl;;
		cin >> op;

		switch(op)
		{
			case 1 : 	//Login to existing account
					if((i = atm.login()) >= 0)
					{
						cout << endl << "Logged In Successfully" << endl;

						log = 1;

						while(log)
						{
							cout << "\n--------------------";
							cout << "\n1. Get Account Details\n2. Check balance\n3. Deposit\n4. Withdraw\n5. Change Password\n6. Logout\n";
							cout << "----------------------" << endl << endl;
							cin >> act;

							account &account = atm.get_account(i);

							switch(act)
							{
								case 1 :	//Get account details
										account.get_details();
										break;

								case 2 :	//Get account Balance
										cout << "Balance : " << account.get_balance() << endl;
										break;

								case 3 :	//Deposit money into account
										account.deposit();
										atm.update_database();
										break;

								case 4 :	//Retreive money from account
										account.retreive();
										atm.update_database();
										break;

								case 5 :	//change account password
										account.change_password();
										atm.update_database();
										break;

								case 6 :	//log out
										cout << endl << "Logged out Successfully" << endl;
										log = 0;
										break;

								default :	//Invalid operation
										cout << "Invalid operation" << endl;
										break;
							}
						}
					}
					else
					{
						cin.clear();
						cin.ignore(1000, '\n');
					}

					break;

			case 2 :	//Register a new account
					atm.reg();
					atm.update_database();
					break;

			case 3 :	//Admin operations
					if(atm.admin_control())
					{
						while(log)
						{

							//admin operations
							cout <<"\n------- Admin Control -------" << endl;
							cout << "1. View all accounts\n2. delete account\n3. Back to Main Menu\n";
							cout << "--------------------\n\n";
							cin >> act;

							switch(act)
							{

								case 1 :	//Display all accounts
										atm.display_all();
										break;

								case 2 :	//delete an account
										atm.del();
										atm.update_database();
										break;

								case 3 :	//log out
										log = 0;
										break;

								default :	//Invalid operation
										cout << "Invalid Operation"<<endl;
										break;

							}

	                                                cin.clear();
        	                                        cin.ignore(1000, '\n');
						}
					}

					break;

			case 4 :	//exit
					cout << "Exiting\n";
					return 0;

			default :	//Invalid operation
					cout << "Invalid Operation" << endl;
					break;
		}

	}


	return 0;

}
