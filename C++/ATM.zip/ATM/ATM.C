
/*----------------------------------------------------------------
 * FILE:        ATM.C
 * AUTHOR:      Harsha S
 * PURPOSE:     Contains all the function definitions
 * DATE:        November 1 ,2025
 -----------------------------------------------------------------*/

#include "ATM.h"

//starting point of account numbers
int account :: start = 12300;

//account number count;
int atm :: account_count = 0;

//constructor of class account
account :: account(string name , int balance , int limit , string password)
        {
                this->name = name;
                this->balance = balance;
                this->limit = limit;
                this->password = password;

                generate_account_no();
        }

//function to generate account number for a new account
void account :: generate_account_no()
	{

		account_no = start;
		start++;

	}

//function to get all the details of an account
void account :: get_details()
	{
		cout << endl << "Account Holder Name : " << name << endl;
		cout << "Account Number : " << account_no << endl;
		cout << "Account Balance : " << balance << endl;
		cout << "Account Transaction Limit : " << limit << endl;
	}

//Function to set transaction limit for an account
void account :: set_limit()
	{
		int nlimit;

		cout << "Enter the new Transaction Limit : ";
		cin >> nlimit;

		this->limit = nlimit;

	}

//Function to change the password for an account
void account :: change_password()
	{
		int retry = 0;

		string opassword;

		while(retry < 3)
		{
			cout << "Enter the previous password : ";
			cin >> opassword;

			if(opassword == password)
			{
				cout << "Enter the new password : ";
				cin >> this->password;
				return;
			}
			else
			{
				cout << "Incorrect Password " << 2 - retry << " Retries left" << endl;
				retry++;
			}
		}

		cout << "Too many Wrong Attempts Password Reset Failed\n";
		return;

	}

//Function to retreive money from an account
int account :: retreive()
	{

		int amount;

		cout << "Current Balance : " << balance << " Current Limit : " << limit << endl;

		cout << "Enter the amount to retreive : ";
		cin >> amount;

		if(amount <= 0)
		{
			cout << "Invalid Amount " << endl;
			return 0;
		}
		else if(amount > balance || balance <= 0)
		{
			cout << "Insufficient Balance" << endl;
			return 0;
		}
		else if(amount > limit)
		{
			cout << "Amount exceeds Limit" << endl;
			return 0;
		}
		else
		{
			balance = balance - amount ;
		}

		cout << "New balance : " << get_balance() << endl;

		return 1;
	}

//Function to deposit money into a account
int account :: deposit()
	{

		int amount;

		cout << "Enter the Amount to deposit : ";
		cin >> amount;

		if(amount <= 0)
		{
			cout << "Invalid Amount " << endl;
			return 0;
		}

		balance += amount;

		cout << "New balance : " << get_balance() << endl;

		return 1;
	}

//Function to get the balance in an account
int account :: get_balance()
	{
		return balance;
	}

//constructor of class atm
atm :: atm()
	{

		read_database();

	}

//function to update atm database into a file
int atm :: update_database()
	{

		FILE *fp = fopen("database.txt","w+");

		fprintf(fp,"%d\n",account_count);

		for(int i = 0 ; i < account_count ; i++)
		{

			fprintf(fp,"%s,%d,%d,%d,%s\n",accounts[i].name.c_str(),accounts[i].account_no,accounts[i].balance,accounts[i].limit,accounts[i].password.c_str());

		}

		fclose(fp);

	        class efile_names files((char*)"database.txt");
		class ebmp_info bmp;
		class eperform_encoding enco;

		enco.encoding(files,bmp);

		remove("database.txt");

		return 0;


	}

//function to load atm database into the atm system
int atm :: read_database()
	{

                class dfile_names files((char*)"database.txt");
                class decode deco;

                deco.perform_decoding(files);

		FILE *fp = fopen("database.txt","r");

		if(fp == NULL)
			return 0;

		fscanf(fp,"%d\n",&account_count);

		for(int i = 0 ; i < account_count ; i++)
		{

			account temp;

			char name[100] , password[100];

			fscanf(fp,"%[^,],%d,%d,%d,%[^,\n]\n",name,&temp.account_no,&temp.balance,&temp.limit,password);

			temp.name = name;
			temp.password = password;

			accounts.push_back(temp);

			account::start = temp.account_no + 1;
		}

		fclose(fp);

                remove("database.txt");

		return 0;

	}

//Function to return reference to a specific account
account& atm :: get_account(int i)
	{
		return accounts[i];
	}

//Function to login into an account
int atm :: login()
	{

		int saccount_no , i ;
		string spassword;

		cout << "Enter the Account Number : ";
		cin >> saccount_no;

		if((i = search_account_no(saccount_no)) != -1)
		{
			cout << "Enter the password : ";
			cin >> spassword;

			if(accounts[i].password == spassword)
			{
				return i;
			}
			else
			{
				cout << "Incorrect Password" << endl;
				return -1;
			}
		}
		else
		{
			cout << "\nAccount does not exist \nPlease register your account\n\n";
			return -1;
		}

	}

//Function to register a new account
int atm :: reg()
	{


		string nname , npassword;

		cout << "Enter the Account Holders Name : ";
		cin >> nname;

		cout << "Enter the Desired Password : ";
		cin >> npassword;

		account naccount(nname,0,1000,npassword);

		cout << "Successfully Created New Account" << endl;

		naccount.get_details();

		accounts.push_back(naccount);

		account_count++;

		return 0;
	}

//Function to delete an existing account
int atm :: del()
	{

		int i = search();

		if(i >= 0)
		{
			accounts[i].get_details();

			auto itr = accounts.begin() + i;

			accounts.erase(itr);

			cout << "Successfully Removed Account\n";

			account_count--;

			return 1;
		}

		return 0;

	}

//Function to search for an account based on name
int atm :: search_name(string sname)
	{

		for(int i = 0 ; i < account_count ; i++)
                {
                        if(accounts[i].name == sname)
                        {
				return i;
                        }
                }

		return -1;
	}

//Function to search for an account based on account number
int atm :: search_account_no(int saccount_no)
	{

		for(int i = 0 ; i < account_count ; i++)
                {
                        if(accounts[i].account_no == saccount_no)
                        {
				return i;
                        }
                }

		return -1;
	}

//Function to search for an account
int atm :: search()
	{

		int op , i = 0;

		cout << "1. Search by Name\n2. Search by Account Number\n";
		cin >> op;

		if(op == 1)
		{
			string sname;

			cout << "Enter the name : ";
			cin >> sname;

			if((i = search_name(sname)) != -1)
			{
				return i;
			}
			else
			{
				cout << "Account Under Name : " << sname  << " not found\n";
				return -1;
			}
		}
		else if(op == 2)
		{
			int saccount_no;

			cout << "Enter the Account Number : ";
			cin >> saccount_no;

			if((i = search_account_no(saccount_no)) != -1)
			{
				return i;
			}
			else
			{
				cout << "Account with Account Number : " << saccount_no << " not found\n";
				return -1;
			}
		}
		else
		{
			cout << "\nInvalid operation\n";
			return -2;
		}

		return -1;

	}

//Function to display all the accounts on the atm system
void atm :: display_all()
	{

		if(account_count == 0)
		{
			cout << endl << "No account present" << endl;
			return;
		}

		for(int i = 0 ; i < account_count ; i++)
		{

			accounts[i].get_details();

		}

	}

int atm :: admin_control()
	{

		int password;

		cout << "Enter the password to access admin control : ";
		cin >> password;

		if(password == admin_password)
		{
			cout << "Admin Access granted"<<endl;
			return 1;
		}

			cout << "Incorrect Password Access denied" << endl;

			return 0;
	}
