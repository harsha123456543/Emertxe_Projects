
/*----------------------------------------------------------------
 * FILE:        ATM.h
 * AUTHOR:      Harsha S
 * PURPOSE:     Contains all the function prototypes
 * DATE:        November 1 ,2025
 -----------------------------------------------------------------*/


#ifndef ATM_H
#define ATM_H

#include <iostream>
#include <vector>
#include <cstdlib>
#include <string>
#include "encode.h"
#include "decode.h"

using namespace std;

//Account class
class account
{

	static int start;

	string name;
	int balance = 0;
	int limit = 0;
	string password;
	int account_no = 0;

	public:

	//function prototypes

	account(string name = "" , int balance = 0, int limit = 1000, string password = "");

	void generate_account_no();

	void get_details();

	void set_limit();

	void change_password();

	int retreive();

	int deposit();

	int get_balance();

	friend class atm;
};

//ATM class
class atm
{

	vector<account> accounts;
	static int account_count;
	int admin_password = 90123;

	public:

	//function prototypes

	atm();

	int read_database();

	int update_database();

	account& get_account(int );

	int login();

	int reg();

	int search();

	int search_name(string );

	int search_account_no(int );

	int del();

	int admin_control();

	void display_all();

};

#endif
