
/*----------------------------------------------------------------
 * FILE:        encode.C
 * AUTHOR:      Harsha S
 * PURPOSE:     Contains all the function definitions
 * DATE:        September 1 ,2025
 -----------------------------------------------------------------*/

#include "encode.h"

//Function to get input bmp file pointer
FILE *efile_names :: get_input_file(void)
	{
        	return input_bmp;
	}

//Function to get secret text file pointer
FILE* efile_names :: get_secret_file(void)
	{
                return secret;
	}

//Function to get secret file name
char *efile_names :: get_secret_filen(void)
	{
		return secret_file;
	}


//Constructor to initialize file names
efile_names :: efile_names(char* file_name)
        {

                input_bmp_file = (char*)"stego.bmp";
                secret_file = strdup(file_name);
        }

//Function to validate files
int efile_names :: validate_files()
        {

                if((input_bmp = fopen(input_bmp_file,"rb+")) == NULL)
                {
                        cout << "Input image file "<<input_bmp_file<<" Does not exist "<<endl;
                        return 1;
                }

                char sig[3] = {0};

                fread(sig,2,1,input_bmp);
                fseek(input_bmp,0,SEEK_SET);

                if(strcmp(sig,"BM"))
                {
                        cout << "Input image file is not of type .bmp"<<endl;
                        return 1;
                }

		fseek(input_bmp,0,SEEK_SET);

                if((secret = fopen(secret_file,"rb")) == NULL)
                {
                        cout << "Secret file "<<secret_file<<" Does not exist "<<endl;
                        return 1;
                }


		return 0;

	}



//Function to calculate total capacity of bmp image file
void ebmp_info :: cal_capacity(class efile_names files)
        {
                fseek(files.get_input_file(),18,SEEK_SET);
                fread(&width,4,1,files.get_input_file());
                fread(&height,4,1,files.get_input_file());

		fseek(files.get_input_file(),0,SEEK_SET);

                capacity = height * width;

	}

//Function to get the capacity of the input bmp file
long ebmp_info :: get_capacity()
        {
                return capacity;
        }



//Function to get secret file data size
int eperform_encoding ::  get_secret_file_size(class efile_names files)
        {
                fseek(files.get_secret_file(),0,SEEK_END);

                secret_file_size = ftell(files.get_secret_file());

                fseek(files.get_secret_file(),0,SEEK_SET);

		return 0;
        }

//Function to check total capacity of input bmp file
int eperform_encoding :: check_capacity(class efile_names files , class ebmp_info bmp)
        {
                if((secret_file_size + 54 + 32 + 32 + 108 + 108) > bmp.get_capacity())
                {
                        return 1;
                }

                return 0;
        }


//Function to encode integer data into lsb
int eperform_encoding :: encode_int_to_lsb(class efile_names files , int size)
        {

                char buffer;

                for(int i = 31 ; i >= 0 ; i--)
                {
                        fread(&buffer,1,1,files.get_input_file());
                        buffer = (buffer & 0xFE) | ((size>>i) & 0x01);
                        fseek(files.get_input_file(),-1,SEEK_CUR);
                        fwrite(&buffer,1,1,files.get_input_file());
                        fflush(files.get_input_file());
                }

                return 0;

        }

//Function to encode 1 byte of data into image lsb byte
int eperform_encoding :: encode_byte_to_lsb(class efile_names files , int data)
        {

                char buffer;

                for(int j = 7 ; j >= 0 ; j--)
                {
                        fread(&buffer,1,1,files.get_input_file());
                        buffer = (buffer & 0xFE) | ((data>>j) & 0x01);
                        fseek(files.get_input_file(),-1,SEEK_CUR);
                        fwrite(&buffer,1,1,files.get_input_file());
                        fflush(files.get_input_file());
                }

                return 0;
        }

//Function to encode magic string size
int eperform_encoding :: encode_magic_string_size(class efile_names files)
        {
                magicstring_size = strlen(MAGIC_STRING);

                encode_int_to_lsb(files,magicstring_size);

		return 0;
        }

//Function to encode magic string
int eperform_encoding :: encode_magic_string(class efile_names files)
        {

                for(int i = 0 ; i < magicstring_size ; i++)
                {
                        encode_byte_to_lsb(files,MAGIC_STRING[i]);
                }

		return 0;
        }

//Function to encode secret file data size
int eperform_encoding :: encode_secret_file_size(class efile_names files)
        {
                fseek(files.get_secret_file(),0,SEEK_END);

                secret_file_size = ftell(files.get_secret_file());

                encode_int_to_lsb(files,secret_file_size);

                fseek(files.get_secret_file(),0,SEEK_SET);

        	return 0;
	}

//Function to encode secret file data
int eperform_encoding :: encode_secret(class efile_names files)
        {

                char data;

                for(int i = 0 ; i < secret_file_size ; i++)
                {
                        fread(&data,1,1,files.get_secret_file());

                        encode_byte_to_lsb(files,data);
                }

		return 0;
        }


//Function to control encoding process
int eperform_encoding :: encoding(class efile_names files , class ebmp_info bmp)
        {
		if(files.validate_files())
		{
			cerr << "Error : Could not operate on files"<<endl;
			return 1;
		}
		else
		{
			//cout << "Successfully Opened and validated files"<<endl;
		}

		bmp.cal_capacity(files);

                fseek(files.get_input_file(),54,SEEK_SET);

		if(get_secret_file_size(files))
		{
			cerr << "Error : Could not get secret file size " << endl;
			return 1;
		}
		else
		{
			//cout << "Successfully obtained secret file size"<<endl;
		}

	        if(check_capacity(files , bmp))
		{
                        cerr << "Error : Image file not large enough to store data " << endl;
                        return 1;
		}
		else
		{
                        //cout << "Image is large enough to encode data "<<endl;
		}

	        if(encode_magic_string_size(files))
		{
                        cerr << "Error : Could not encode magic string size " << endl;
                        return 1;
		}
		else
		{
                        //cout << "Successfully encoded magic string size "<<endl;
		}

	        if(encode_magic_string(files))
		{
                        cerr << "Error : Could not encode magic string " << endl;
                        return 1;
		}
		else
		{
                        //cout << "Successfully encoded magic string"<<endl;
		}

	        if(encode_secret_file_size(files))
		{
                        cerr << "Error : Could not encode secret file size " << endl;
                        return 1;
		}
		else
		{
                        //cout << "Successfully encoded secret file data size"<<endl;
		}

	        if(encode_secret(files))
		{
                        cerr << "Error : Could not encode secret file data " << endl;
                        return 1;
		}
		else
		{
                        //cout << "Successfully encoded secret file data"<<endl;
		}

		return 0;
        }

