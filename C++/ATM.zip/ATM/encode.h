
/*----------------------------------------------------------------
 * FILE:        encode.h
 * AUTHOR:      Harsha S
 * PURPOSE:     Contains all the classes and function prototypes
 * DATE:        Sepetember 1, 2025
 -----------------------------------------------------------------*/

#ifndef ENCODE_H
#define ENCODE_H

#include <iostream>
#include <cstdlib>
#include <string>
#include <cstring>

#define MAGIC_STRING "#*;"

using namespace std;

//Class for file operations
class efile_names
{

	char* input_bmp_file;
	char* secret_file;

	FILE *input_bmp;
	FILE *secret;

	public:

	FILE *get_input_file(void);

	FILE *get_secret_file(void);

	char *get_secret_filen(void);

	efile_names(char *);

	int validate_files();

};

//Class for encoding operations
class ebmp_info
{
        long capacity;
        int height;
        int width;

        public:

        void cal_capacity(class efile_names files);

        long get_capacity();
};

class eperform_encoding
{

	int magicstring_size;
	int secret_file_size;

	char* secret_file_ext;

	public:

        int get_secret_file_size(class efile_names files);

	int check_capacity(class efile_names files ,class ebmp_info bmp);

	int encode_int_to_lsb(class efile_names files , int size);

	int encode_byte_to_lsb(class efile_names files , int data);

	int encode_magic_string_size(class efile_names files);

	int encode_magic_string(class efile_names files);

        int encode_secret_file_size(class efile_names files);

	int encode_secret(class efile_names files);

	int encoding(class efile_names files , class ebmp_info bmp);

};

#endif
