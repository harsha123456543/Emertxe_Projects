
/*----------------------------------------------------------------
 * FILE:        main.C
 * AUTHOR:      Harsha S
 * PURPOSE:     Performs all the operations
 * DATE:        September 1, 2025
 -----------------------------------------------------------------*/

#include "encode.h"
#include "decode.h"

//Controls all the opertions
int main(int argc , char* argv[])
{

        if(argc >= 2 && !strcmp(argv[1],"--help"))
        {

                cout << "For Encoding Type ./a.out -e bmp_file_name.bmp secret_file.{extension} output_image_file.bmp {optional}" << endl;
                cout << "For Decoding Type ./a.out -d bmp_file_name.bmp decoded_output.{extension} {optional}" << endl;

                return 0;
        }


	if(argc < 3)
	{
		cout << "Incorrect arguements type ./a.out --help for the help menu"<<endl;
		return 0;
	}

	if(!strcmp(argv[1],"-e"))
	{

		class efile_names files(argc,argv);
		class ebmp_info bmp;
		class eperform_encoding enco;

		if(enco.encoding(files,bmp))
		{
			cerr << "Operation Unsuccessful"<<endl;
			return 1;
		}
		else
		{
			cout << "Encode Operation completed successfully"<<endl;
			cout << "Ouput file -> " << files.get_outputn() << endl;
		}

		return 0;

	}

	else if(!strcmp(argv[1],"-d"))
	{

		class dfile_names files(argc,argv);
		class decode deco;

		if(deco.perform_decoding(files))
		{
			cerr << "Operation Unsuccessful"<<endl;
			return 1;
		}
		else
		{
			cout << "Decode Operation completed successfully" << endl;
			cout << "Output file -> " << files.get_decodedn() << endl;
		}

		return 0;

	}

	else
	{

		cerr << "Incorret operation type type ./a.out --help for the help menu";
		return 0;

	}


	return 0;

}
