
/*----------------------------------------------------------------
 * FILE:        decode.h
 * AUTHOR:      Harsha S
 * PURPOSE:     Contains all the classes and function prototypes
 * DATE:        September 1, 2025
 -----------------------------------------------------------------*/

#ifndef DECODE_H
#define DECODE_H

#include <bits/stdc++.h>

#define PASSWORD "#*;"

using namespace std;

//Class for file operations
class dfile_names
{
	char *input_bmp_file = NULL;
	char *decoded_file = NULL;

	FILE *input_bmp;
	FILE *decoded;

	public:

	dfile_names(int , char *[]);

	FILE *get_input_bmp();

	FILE *get_decoded();

	char *get_decodedn();

	void update_decoded(char *file_name);

	int validate_files();

};

//Class for decoding operations
class decode
{

	int magic_string_size;
	int secret_file_ext_size;
	int secret_file_size;

	char magic_string[20];
	char secret_file_ext[20];

	public :

	int decode_lsb_to_int(dfile_names &);

	char decode_lsb_to_byte(dfile_names &);

	int decode_magic_string_size(dfile_names &);

	int decode_magic_string(dfile_names &);

	int decode_secret_ext_size(dfile_names &);

	int decode_secret_ext(dfile_names &);

	int decode_secret_file_size(dfile_names &);

	int decode_secret_file(dfile_names &);

	int perform_decoding(dfile_names &);
};

#endif



