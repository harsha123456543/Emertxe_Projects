
/*----------------------------------------------------------------
 * FILE:        decode.C
 * AUTHOR:      Harsha S
 * PURPOSE:     Contains all the function definitions
 * DATE:        September 1, 2025
 -----------------------------------------------------------------*/

#include "decode.h"

//Constructor to initialize file names
dfile_names :: dfile_names(int argc , char *argv[])
        {

		if(argc >= 3)
		{
                	input_bmp_file = argv[2];

                	if(argc > 3)
                	{
                        	decoded_file = argv[3];
                	}
                	else
                	{
                        	decoded_file = NULL;
                	}
		}
		else
		{
			cerr << "Insufficient number of files provided"<<endl;
			exit(0);
		}

        }

//Function to get input bmp file pointer
FILE *dfile_names :: get_input_bmp()
        {
                return input_bmp;
        }

//Function to get output file name
char *dfile_names :: get_decodedn()
	{
		return decoded_file;
	}

//Function to get output file pointer
FILE *dfile_names :: get_decoded()
        {
                return decoded;
        }

//Function to update output file name
void dfile_names :: update_decoded(char *file_name)
        {
                decoded_file = file_name;

                decoded = fopen(decoded_file,"wb");
        }

//Function to validate files
int dfile_names :: validate_files()
        {

                if((input_bmp = fopen(input_bmp_file,"rb")) == NULL)
                {
                        cout << "Input BMP file does not exist"<<endl;
			return 1;
                }

                char sig[3] = {0};

                fread(sig,1,2,input_bmp);

                if(strcmp(sig,"BM"))
                {
                        cout << "Input BMP file is not a BMP file"<<endl;
			return 1;
                }

		if(decoded_file != NULL)
		{
			if((decoded = fopen(decoded_file,"wb")) == NULL)
			{
				return 1;
			}
		}

		return 0;
        }


//Function to decode lsb bit into integer value
int decode :: decode_lsb_to_int(dfile_names &files)
	{
		char buffer = 0;
		int size = 0;

		for(int i = 31 ; i >= 0 ; i--)
		{
			fread(&buffer,1,1,files.get_input_bmp());
			size = (size<<1)|(buffer & 0x01);
		}

		return size;

	}

//Function to decode lsb bits into 1 byte of data
char decode :: decode_lsb_to_byte(dfile_names &files)
	{

		char buffer[8] = {0};
		char data = 0;

		fread(&buffer,1,8,files.get_input_bmp());

		for(int j = 0 ; j < 8 ; j++)
		{
			data = (data<<1)|(buffer[j] & 0x01);
		}

		return data;

	}

//Function to decode magic string size
int decode :: decode_magic_string_size(dfile_names &files)
	{

		fseek(files.get_input_bmp(),54,SEEK_SET);

		magic_string_size = decode_lsb_to_int(files);

		return 0;
	}

//Function to decode magic string
int decode :: decode_magic_string(dfile_names &files)
	{

		for(int i = 0 ; i < magic_string_size ; i++)
		{
			magic_string[i] = decode_lsb_to_byte(files);
		}

		if(!strcmp(magic_string,PASSWORD))
			return 0;

		cerr << "Error : Magic String Mismatch"<<endl;
		return 1;
	}

//Function to decode secret file extension size
int decode :: decode_secret_ext_size(dfile_names &files)
	{

		secret_file_ext_size = decode_lsb_to_int(files);

		return 0;
	}

//Function to decode secret file extension
int decode :: decode_secret_ext(dfile_names &files)
	{

		for(int i = 0 ; i < secret_file_ext_size ; i++)
		{
			secret_file_ext[i] = decode_lsb_to_byte(files);
		}

		char *dec_file_name = (char*)calloc(64,1);

		strcpy(dec_file_name,"decoded.");
		strcat(dec_file_name,secret_file_ext);

		if(files.get_decodedn() == NULL)
		{
			files.update_decoded(dec_file_name);
		}

		return 0;
	}

//Function to decode secret data size
int decode :: decode_secret_file_size(dfile_names &files)
	{

		secret_file_size = decode_lsb_to_int(files);

		return 0;
	}

//Function to decode secret data
int decode :: decode_secret_file(dfile_names &files)
	{

		char data;

		for(int i = 0 ; i < secret_file_size ; i++)
		{
			data = decode_lsb_to_byte(files);
			fwrite(&data,1,1,files.get_decoded());
		}

		return 0;
	}

//Function to control decoding operations
int decode :: perform_decoding(dfile_names &files)
	{

		if(files.validate_files())
		{
                        cerr << "Error : Could not operate on files"<<endl;
                        return 1;
		}
		else
		{
                        cout << "Successfully Opened and validated files"<<endl;
		}

		if(decode_magic_string_size(files))
		{
                        cerr << "Error : Could not decode magic string size " << endl;
                        return 1;
		}
		else
		{
                        cout << "Successfully decoded magic string size "<<endl;
		}

	        if(decode_magic_string(files))
		{
                        cerr << "Error : Could not decode magic string " << endl;
                        return 1;
		}
		else
		{
                        cout << "Successfully decoded magic string"<<endl;
		}

        	if(decode_secret_ext_size(files))
		{
                        cerr << "Error : Could not decode secret file extension size " << endl;
                        return 1;
		}
		else
		{
                        cout << "Successfully decoded secret file extension size"<<endl;
		}

        	if(decode_secret_ext(files))
		{
                        cerr << "Error : Could not decode secret file extension " << endl;
                        return 1;
		}
		else
		{
                        cout << "Successfully decoded secret file extension"<<endl;
		}

        	if(decode_secret_file_size(files))
		{
                        cerr << "Error : Could not decode secret file size " << endl;
                        return 1;
		}
		else
		{
                        cout << "Successfully decoded secret file data size"<<endl;
		}

        	if(decode_secret_file(files))
		{
                        cerr << "Error : Could not decode secret file data " << endl;
                        return 1;
		}
		else
		{
                        cout << "Successfully decoded secret file data"<<endl;
		}

		return 0;
	}

