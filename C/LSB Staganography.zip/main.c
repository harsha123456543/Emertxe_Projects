#include <stdio.h>
#include <string.h>
#include "encode.h"
#include "types.h"
#include "common.h"
#include "decode.h"

int main(int argc, char *argv[])
{
    // Function call for check operation type
    if (check_operation_type(argv) == e_encode)
    {
        printf("Selected encoding\n");

        EncodeInfo encInfo;
        // Read and validate encode arguments
        if (read_and_validate_encode_args(argv, &encInfo) == e_success)
        {
            printf("Successfully Read CLA\n");

	encInfo.src_image_fname = argv[2];
	encInfo.secret_fname = argv[3];

            printf("Started Encoding\n");

            // Function call for encoding
            if (do_encoding(&encInfo) == e_success)
            {
                printf("Completed encoding\n");
            }
            else
            {
                printf("Failed to encode\n");
                return e_failure;
            }
        }
        else
        {
            printf("Read and validate encode arguments is a failure\n");
            return e_failure;
        }
    }
    else if (check_operation_type(argv) == e_decode)
    {

        DecodeInfo decInfo;
        if (read_and_validate_decode_args(argv, &decInfo) == d_success)
        {
            printf("Successfully Read and Encoded CLA\n");
            printf("Started Decoding\n");

            // Function call for do decoding
            if (do_decoding(&decInfo) == d_success)
            {
                printf("Completed decoding\n");
            }
            else
            {
                printf("Failed to decode\n");
                 return e_failure;
            }
        }
        else
        {
            printf("Read and validate decode arguments is a failure\n");
             return e_failure;
        }
    }
    else
    {
        printf("Invalid Input \nType \nEncoding: ./a.out -e beautiful.bmp secret.ext stego.bmp\nDecoding: ./a.out -d stego.bmp decode.ext\n");
    }
    return 0;
}
