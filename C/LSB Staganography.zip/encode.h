#ifndef ENCODE_H
#define ENCODE_H

#include "types.h" // Contains user defined types

/*
 * Structure to store information required for
 * encoding secret file to source Image
 */
#define MAX_SECRET_BUF_SIZE 1
#define MAX_IMAGE_BUF_SIZE (MAX_SECRET_BUF_SIZE * 8)
#define MAX_FILE_SUFFIX 4

typedef struct _EncodeInfo
{
    /* Source Image info */
    char *src_image_fname;
    FILE *fptr_src_image;
    uint image_capacity;
    uint bits_per_pixel;
    char image_data[MAX_IMAGE_BUF_SIZE];

    /* Secret File Info */
    char *secret_fname;
    FILE *fptr_secret;
    char extn_secret_file[MAX_FILE_SUFFIX];
    char secret_data[MAX_SECRET_BUF_SIZE];
    long size_secret_file;

    /* Stego Image Info */
    char *stego_image_fname;
    FILE *fptr_stego_image;

} EncodeInfo;


/*
 *Function Prototype
*/

//Check operation type
OperationType check_operation_type(char *argv[]);

//Read and validate Command Line arguements
Status read_and_validate_encode_args(char *argv[], EncodeInfo *encInfo);

//Perform encoding
Status do_encoding(EncodeInfo *encInfo);

//Open input and output files
Status open_files(EncodeInfo *encInfo);

// check capacity of the BMP File
Status check_capacity(EncodeInfo *encInfo);

//Get image size of the BMP File
uint get_image_size_for_bmp(FILE *fptr_image);

//Get size of the secret file
long get_file_size(FILE *fptr);

//Copy bmp image header
Status copy_bmp_header(FILE *fptr_src_image, FILE *fptr_dest_image);

//Encode Magic string into BMP image File
Status encode_magic_string(char *magic_string, EncodeInfo *encInfo);

//Encode Secret file extension size
Status encode_secret_file_extn_size(int size, FILE *fptr_src_image, FILE *fptr_stego_image);

//Encode secret file extension
Status encode_secret_file_extn(char *file_extn, EncodeInfo *encInfo);

//Encode secret file size
Status encode_secret_file_size(int file_size, EncodeInfo *encInfo);

//Encode secret file data
Status encode_secret_file_data(EncodeInfo *encInfo);

//Encode data of secret file into BMP image file
Status encode_data_to_image(char *data, int size, FILE *fptr_src_image, FILE *fptr_stego_image, EncodeInfo *encInfo);

//Encode a data of secret file into LSB of each pixel of BMP image file
Status encode_byte_to_lsb(char data, char *image_buffer);

//Encode size of secret message to lsb of BMP image file
Status encode_size_to_lsb(int size, char *image_buffer);

//Copy remaining image bytes into BMP image copy
Status copy_remaining_img_data(FILE *fptr_src, FILE *fptr_dest);

#endif
