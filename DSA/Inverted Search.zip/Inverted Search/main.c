
/*----------------------------------------------------------------
 * FILE:        main.c
 * AUTHOR:      Harsha S
 * PURPOSE:     Performs the operation
 * DATE:        August 12, 2025
 -----------------------------------------------------------------*/

//Contains function prototypes and Hash table structure
#include "IS.h"

int main(int count , char *names[])
{

	char choice;
	files *head = NULL;
	char sfilename[100];
	char bfilename[100];
	int eflag = 0;

	//If incorrect arguments are passed
	if(count == 1)
	{
		fprintf(stderr,"ERROR : Enter ./a.out (file name).txt \n");
		exit(0);
	}

	else
	{

		//Hash table
		main_node *arr[27];

		for(int i = 0 ; i < 27 ; i++)
		{
			arr[i] = NULL;
		}

		FILE *fp = NULL;
		FILE *save = NULL;

		char search[50];


		while(1)
		{
			//Operations menu
			printf("Select the operation to perform :\n");

			printf("\n1. Create database \n2. Display database\n3. Search database\n4. Save database\n5. Update database\n6. Exit\n\n");
			scanf(" %c",&choice);

			switch(choice)
			{
				case '1' :	{
							if(eflag == 0)
							{
						                create_file_list(count,names,&head);
						                print_list(head);

								create_database(arr,fp,count,names);
								printf("Successfully Create Database\n\n");
								eflag = 1;
							}
							else
							{
								printf("ERROR : Database Already Created\n\n");
							}
						}
						break;
				case '2' :	{
							if(eflag == 0)
							{
								printf("ERROR : Database is Empty\n\n");
							}
							else
							{
								display_database(arr);
							}
							printf("\n");
						}
						break;
				case '3' :	{
							if(eflag == 1)
							{
								printf("Enter the data to search for : ");
								scanf(" %s",search);
								if(search_database(arr,search) == 1)
								{
									printf("Data was not Found\n");
								}
							}
							else
							{
								printf("ERROR : Database is Empty\n");
							}
							printf("\n");
						}
						break;
				case '4' :	{
							if(eflag == 1)
							{
								printf("Enter the file name : ");
								scanf("%s",sfilename);

								if(save_database(arr,sfilename) != 0)
								{
									printf("Database saved Successfully\n\n");
								}
							}
							else
							{
								printf("ERROR : Database is Empty\n");
							}
							printf("\n");
						}
						break;
				case '5' :	{
							if(eflag == 0)
							{
								printf("Enter the backup file name : ");
								scanf("%s",bfilename);

								head = NULL;

								if(update_database(arr,bfilename,&head) == 0)
								{
									fprintf(stderr,"\nERROR : Could not Update Database\n\n");
									break;
								}

								print_list(head);

								printf("Successfully Updated Database\n\n");

								eflag = 1;
							}
							else
							{
								printf("ERROR : Cannot Update database as data is already present\n");
							}
							printf("\n");
						}
						break;
				case '6' :	{
							printf("\nExiting\n");
						}
						return 0;
			}

		}

	}




	return 0;

}
