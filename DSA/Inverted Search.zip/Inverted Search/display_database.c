
/*----------------------------------------------------------------
 * FILE:        display_database.c
 * AUTHOR:      Harsha S
 * PURPOSE:     Contains the function to display database
 * DATE:        August 12, 2025
 -----------------------------------------------------------------*/

#include "IS.h"

//Function to display the entire database
int display_database(main_node *arr[27])
{

	printf("\n");

	for(int i = 0 ; i < 27 ; i++)
	{
		main_node *mtemp = arr[i];

		//Traverse the hashtable main nodes and print the elements
		while(mtemp)
		{

			printf("Index\t Word\t File count\t File name \tWord count\n");

			printf("%-8d %-9s %-14d",i,mtemp->word,mtemp->filecount);

			sub_node *stemp = mtemp->slink;

			//Traverse the sub node and print elements
			while(stemp)
			{
				if(stemp == mtemp->slink)
				{
					printf("%-10s %8d\n",stemp->file_name,stemp->wordcount);
				}
				else
				{
					printf("\t\t\t\t %-10s %8d\n",stemp->file_name,stemp->wordcount);
				}

				stemp = stemp->link;
			}

			printf("\n");
			mtemp = mtemp->mlink;
		}

	}

	return SUCCESS;

}
	
