
/*----------------------------------------------------------------
 * FILE:        search_database.c
 * AUTHOR:      Harsha S
 * PURPOSE:     Contains the function to search the database for an element
 * DATE:        August 12, 2025
 -----------------------------------------------------------------*/

#include "IS.h"

//Function to search the database for an element
int search_database(main_node *arr[27] , char *data)
{

	//Calculate the index
	int index = (toupper(data[0]))%65;

	if(index < 0 || index > 25)
	{
		index = 26;
	}

	main_node *mtemp = arr[index];

	//Traverse the hashtable and search for the element
	while(mtemp)
	{

		//If the data was found print all its info
		if(strcmp((mtemp->word),data) == 0)
		{
			printf("Data Found in %d Files\n",mtemp->filecount);

			sub_node *stemp = mtemp->slink;

			printf("File name\tWord count\n");

			while(stemp)
                        {
                                printf("%-10s %8d\n",stemp->file_name,stemp->wordcount);
                                stemp = stemp->link;
                        }

			return SUCCESS;
		}

		mtemp = mtemp->mlink;
	}

	//If data was not found in the hashtable
	return FAILURE;
}



