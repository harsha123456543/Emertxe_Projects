
/*----------------------------------------------------------------
 * FILE:        create_database.c
 * AUTHOR:      Harsha S
 * PURPOSE:     Contains all functions to create database
 * DATE:        August 12, 2025
 -----------------------------------------------------------------*/

#include "IS.h"

//Insert data into the hashtable
int insert_data(main_node *arr[27] , FILE *fp , char *file_name)
{
	char buffer[100];
	int index = 0;
	int found = 0;

	//Read data from file
	while(fscanf(fp,"%s",buffer) == 1)
	{
		found = 0;

		//Calculate the index
		index = (toupper(buffer[0])%65);

		//Check if it is a special character
		if(index >= 0 && index <= 25);
		else
		{
			index = 26;
		}

		//Check if that index of the hashtable is empty
		if(arr[index] == NULL)
		{
			create_main_node(arr,index,file_name,buffer);
		}

		//If not empty add new nodes at the end
		else
		{
			main_node *mtemp = arr[index];

			while(mtemp)
			{
				//If there are repeating words
				if(strcmp((mtemp->word),buffer) == 0)
				{
					create_sub_node(mtemp,file_name);
					found = 1;
				}

				mtemp = mtemp->mlink;

			}

			//If it is a new word
			if(!found)
			{
				create_main_node(arr,index,file_name,buffer);
			}
		}

	}


}


//Create hashtable from data present in the files
int create_database(main_node *arr[27] , FILE *fp , int count  ,char *names[])
{

	for(int i = 1 ; i < count ; i++)
	{
		fp = fopen(names[i],"r");

		insert_data(arr,fp,names[i]);
	}


}
