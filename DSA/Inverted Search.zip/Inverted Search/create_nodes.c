
/*----------------------------------------------------------------
 * FILE:        create_nodes.c
 * AUTHOR:      Harsha S
 * PURPOSE:     Contains all functions to create nodes
 * DATE:        August 12, 2025
 -----------------------------------------------------------------*/


#include "IS.h"


//Function to create sub node
int create_sub_node(main_node *temp , char *file_name)
{

	sub_node *stemp = temp->slink;

	while(stemp)
	{
		//If word is already present increase word count
		if(strcmp((stemp->file_name),file_name) == 0)
		{
			(stemp->wordcount)++;
			return SUCCESS;
		}

		stemp = stemp->link;
	}

	stemp = temp->slink;

	//If word is new add it to the end of the sub nodes
	while(stemp)
	{
		if(stemp->link == NULL)
		{
			break;
		}

		stemp = stemp->link;

	}

	sub_node *snew = malloc(sizeof(sub_node));

	snew->wordcount = 1;
	strcpy(snew->file_name,file_name);
	snew->link = NULL;

	stemp->link = snew;
	(temp->filecount)++;

	return SUCCESS;

}

//Function to create main node
int create_main_node(main_node *arr[27] , int index , char *file_name , char *buffer)
{

        main_node *mnew = malloc(sizeof(main_node));
        sub_node *snew = malloc(sizeof(sub_node));

        if(mnew == NULL || snew == NULL)
        {
                fprintf(stderr,"ERROR while creating nodes\n");
                exit(0);
        }

        mnew->filecount = 1;
        strcpy(mnew->word,buffer);
        mnew->mlink = NULL;
        mnew->slink = snew;

        snew->wordcount = 1;
        strcpy(snew->file_name,file_name);
        snew->link = NULL;


	//If hashtable index is empty append the node directly
	if(arr[index] == NULL)
	{
		arr[index] = mnew;

		return SUCCESS;
	}

	//If not empty traverse through the list to find the last node and append it there
	else
	{
		main_node *temp = arr[index];

		while(temp)
		{
			if(temp->mlink == NULL)
			{
				break;
			}

			temp = temp->mlink;
		}

		temp->mlink = mnew;

		return SUCCESS;
	}

	return FAILURE;
}



