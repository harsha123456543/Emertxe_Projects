
/*----------------------------------------------------------------
 * FILE:        IS.h
 * AUTHOR:      Harsha S
 * PURPOSE:     Contains all the function Prototypes
 * DATE:        August 12, 2025
 -----------------------------------------------------------------*/

#ifndef IS_H
#define IS_H

#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>

#define SUCCESS 0
#define FAILURE 1

//Structure for link list
typedef struct files
{
char filename[20];
struct files *link;
}files;

//Structures for Hashtable nodes
typedef struct sub
{
int wordcount;
char file_name[20];
struct sub *link;
}sub_node;


typedef struct main
{
int filecount;
char word[50];
sub_node *slink;
struct main *mlink;
}main_node;

//Function Prototypes
void create_file_list(int , char *[] , files ** );

void insert_file_list(char * , files ** , int );

int create_database(main_node ** ,FILE * , int , char *[]);

int insert_data(main_node ** , FILE *, char *);

int create_sub_node(main_node * , char *);

int create_main_node(main_node ** , int  , char * , char *);

int display_database(main_node **);

int search_database(main_node ** , char *);

int save_database(main_node ** , char *);

int update_database(main_node ** , char * , files **);

void print_list(files *);

#endif
