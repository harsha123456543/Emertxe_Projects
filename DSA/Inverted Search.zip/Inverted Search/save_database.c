
/*----------------------------------------------------------------
 * FILE:        save_database.c
 * AUTHOR:      Harsha S
 * PURPOSE:     Contains the function to save database
 * DATE:        August 12, 2025
 -----------------------------------------------------------------*/

#include "IS.h"

//Function to save the database into the backup file
int save_database(main_node *arr[27] , char *file_name)
{

	//Check if the backup file is .txt extension
	if(strstr(file_name,".txt") == NULL)
	{
		fprintf(stderr,"Only .txt files are allowed\n");
		return 0;
	}


	FILE *fp = fopen(file_name,"w");

	//Traverse the hashtable
	for(int i = 0 ; i < 27 ; i++)
	{
		main_node *mtemp = arr[i];

		//Traverse main nodes
		while(mtemp)
		{
			fprintf(fp,"# %d ; %s ; %d ",i,mtemp->word,mtemp->filecount);

			sub_node *stemp = mtemp->slink;

			//Traverse sub nodes
			while(stemp)
			{
				fprintf(fp,"; %s ; %d ",stemp->file_name,stemp->wordcount);

				stemp = stemp->link;
			}

				fprintf(fp,"#\n");

				mtemp = mtemp->mlink;
		}
	}

	fclose(fp);

	return 1;

}
