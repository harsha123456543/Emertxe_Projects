
/*----------------------------------------------------------------
 * FILE:        Create_file_list.c
 * AUTHOR:      Harsha S
 * PURPOSE:     Contains all functions to create file linked list
 * DATE:        August 12, 2025
 -----------------------------------------------------------------*/

#include "IS.h"


//Function to create file list
void insert_file_list(char *name , files **head , int  up)
{
	FILE *fp = NULL;

	//Check if file has .txt extension
	if(strstr(name,".txt") != NULL)
	{
		//Check if the file exists
		if((fp = fopen(name,"r")) != NULL)
		{
			files *temp = *head;

                       	files *new = malloc(sizeof(files));
                       	strcpy(new->filename,name);
                       	new->link = NULL;

			if(*head == NULL)
			{
				*head = new;
				return;
			}

			while(temp != NULL)
			{
				//Check for duplicates
				if(strcmp(temp->filename,name) == 0)
				{
					if(up == 0)
					{
						fprintf(stderr,"ERROR : Duplicate file names not allowed \"%s\" \n",name);
						exit(0);
					}
					else
					{
						return;
					}
				}
				temp = temp->link;
			}

			temp = *head;

			while(temp->link != NULL)
			{
				temp = temp->link;
			}

			temp->link = new;
		}
		else
		{
			if(up == 0)
			{
				fprintf(stderr,"ERROR : File Does not exist \"%s\" \n",name);
				exit(0);
			}
		}
	}
	else
	{
		if(up == 0)
		{
			fprintf(stderr,"ERROR : File must be .txt extension only \"%s\" \n", name);
			exit(0);
		}
	}

}

//Function to create file list for files passed during create database
void create_file_list(int count , char *names[] , files **head)
{
	for(int i = 1 ; i < count ; i++)
	{
		insert_file_list(names[i],head,0);
	}
}


//Function to print file list
void print_list(files *head)
{

	printf("\n");

	while(head != NULL)
	{
		printf("Successfully added File -> %s to the database\n",head->filename);

		head = head->link;
	}

	printf("\n");

}
