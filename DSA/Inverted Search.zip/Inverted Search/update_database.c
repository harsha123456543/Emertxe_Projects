
/*----------------------------------------------------------------
 * FILE:        update_database.c
 * AUTHOR:      Harsha S
 * PURPOSE:     Contains the function to update database
 * DATE:        August 12, 2025
 -----------------------------------------------------------------*/

#include "IS.h"

//Function to update the database using the backup file
int update_database(main_node *arr[27] , char *backup_file , files **head)
{

	FILE *fp = fopen(backup_file,"r");

	//Check if the backup file exists
	if(fp == NULL)
	{
		fprintf(stderr,"Could not open %s file",backup_file);
		return 0;
	}

	//Check if the backup file has .txt extension
	if(strstr(backup_file,".txt") == NULL)
	{
		fprintf(stderr,"Only .txt files are allowed \n");
		return 0;
	}


	char buffer[100];
	char c;

	int count = 0;

	char sword[50];
	int sfilecount;
	int sindex;
	char sfilename[50];
	int swordcount;


	//Check if the first character of the backup file is #
	if((c = fgetc(fp)) != '#')
	{
		fprintf(stderr,"Not a backup file");
		return 0;
	}

	fseek(fp,0,SEEK_SET);

	//Read every element of the backup file and store it in the database
	while(fscanf(fp,"%s",buffer) == 1)
	{
		//Reading 1 line at a time
		if(buffer[0] == '#' && count == 0)
		{
			int fflag = 1;

			fscanf(fp,"%d ; %s ; %d ; %s ; %d ",&sindex,sword,&sfilecount,sfilename,&swordcount);

			insert_file_list(sfilename,head,1);

			create_main_node(arr,sindex,sfilename,sword);

			main_node *temp1 = arr[sindex];

			while(temp1->mlink)
			{
				temp1 = temp1->mlink;
			}

			for(int i = 1 ; i < swordcount ; i++)
			{
				create_sub_node(temp1,sfilename);
			}

			for(int i = 1 ; i < sfilecount ; i++)
			{
				fscanf(fp," ; %s ; %d",sfilename,&swordcount);

	                        insert_file_list(sfilename,head,1);

				for(int j = 0 ; j < swordcount ; j++)
				{
					create_sub_node(temp1,sfilename);
				}
			}
			count++;
		}
		else if(buffer[0] == '#' && count == 1 )
		{
			count = 0;
		}
	}


}
