/*----------------------------------------------------------------
 * FILE:        apc.c
 * AUTHOR:      Harsha S
 * PURPOSE:     Contains all the function definitions
 * DATE:        August 4, 2025
 -----------------------------------------------------------------*/

//Contains function prototypes and Double Linked list structure
#include "apc.h"

/*----------------------------------------------------------------
 * FUNCTION:    insert_first
 * PURPOSE:     Insert a new Node at the starting position of the Linked List
 * PARAMETERS:  **head - pointer to the pointer to the first Node of the Linked list
		**tail - pointer to the pointer to the last Node of the Linked list
 *              data - value to be stored in the Node
 * RETURNS:     0 if Node was successfully created
 *              -1 if Node was not created
 -----------------------------------------------------------------*/
int insert_first(dlist **head , dlist **tail , int data)
{

	dlist *new = calloc(sizeof(dlist) , 1);

	if(new == NULL)
	{
		return -1;
	}

	new->data = data;
	new->prev = NULL;
	new->next = NULL;

	if(*head == NULL)
	{
		*head = new;
		*tail = new;
		return 0;
	}

	dlist *temp = *head;

	*head = new;
	new->next = temp;
	temp->prev = new;

	return 0;

}

/*----------------------------------------------------------------
 * FUNCTION:    create_dlist
 * PURPOSE:     Create a Double Linked list and store all the data into the Nodes
 * PARAMETERS:  *operand - the string with the operand
		**head - pointer to the pointer to the first Node of the Linked list
                **tail - pointer to the pointer to the last Node of the Linked list
 * RETURNS:     0 if Double Linked List was created Successfully
 -----------------------------------------------------------------*/
int create_dlist(char *operand , dlist **head , dlist **tail)
{
	int i = strlen(operand)-1;

	//create node a first position and insert the value
	while(i >= 0)
	{
		insert_first(head,tail,(operand[i] - '0'));
		i--;
	}

	return 0;

}


/*----------------------------------------------------------------
 * FUNCTION:    add
 * PURPOSE:     Add data present in both double linked lists and store it back into the first Double linked list
 * PARAMETERS:  **head1 - pointer to the pointer to the first Node of the first Linked list
                **tail1 - pointer to the pointer to the last Node of the first Linked list
		**tail2 - pointer to the pointer to the last Node of the second Linked list
 * RETURNS:     0 if operation was completed Successfully
 -----------------------------------------------------------------*/
int add(dlist **head1 , dlist **tail1 , dlist **tail2)
{
	int carry = 0;

	dlist *temp1 = *tail1 , *temp2 = *tail2;

	//Add values present in list 1 and list 2 and store it in link 1
	while(*tail1 != NULL && *tail2 != NULL)
	{
		int sum = ((*tail1)->data + (*tail2)->data + carry);

		carry = sum/10;

		(*tail1)->data = sum%10;

		(*tail1) = (*tail1)->prev;

		(*tail2) = (*tail2)->prev;
	}

	//If list 2 has more nodes store the sum into list 2
	while(*tail2 != NULL)
	{
		int data = ((*tail2)->data + carry);

		carry = data/10;

		insert_first(head1,tail1,data%10);
		(*tail2) = (*tail2)->prev;
	}

	//If list 1 has more nodes store the sum into list 1
	while(*tail1 != NULL)
	{
		int data = ((*tail1)->data + carry);

		carry = data/10;

		(*tail1)->data = data%10;
		(*tail1) = (*tail1)->prev;
	}

	//Check if there is an extra carry and add it to list 1
	if(carry)
	{
		insert_first(head1,tail1,1);
	}

	*tail1 = temp1 , *tail2 = temp2;

	return 0;

}

/*----------------------------------------------------------------
 * FUNCTION:    sub
 * PURPOSE:     Subtract data present in both double linked lists and store it back into the first Double linked list
 * PARAMETERS:  **head1 - pointer to the pointer to the first Node of the first Linked list
                **tail1 - pointer to the pointer to the last Node of the first Linked list
		**tail2 - pointer to the pointer to the last Node of the second Linked list
		neg - Number to signify if the the final operation should result in a negative number
 * RETURNS:     0 if operation was completed successfully
 -----------------------------------------------------------------*/
int sub(dlist **head1 , dlist **tail1 , dlist **tail2 , int neg)
{
        int borrow = 0;

	dlist *temp1 = *tail1 , *temp2 = *tail2;

	//Subtract the values present in list 1 from list 2 and store the result into list 1
        while(*tail1 != NULL && *tail2 != NULL)
        {
                int sum = ((*tail1)->data - (*tail2)->data + borrow);

                if(sum < 0)
		{
			borrow = -1;
			(*tail1)->data = (sum+10)%10;
		}
		else
		{
			borrow = 0;
			(*tail1)->data = (sum % 10);
		}

                (*tail1) = (*tail1)->prev;
                (*tail2) = (*tail2)->prev;
        }

	//If list 1 has more nodes
        while(*tail1 != NULL)
        {
                int data = ((*tail1)->data + borrow);

		if(data < 0)
		{
			borrow = -1;
			(*tail1)->data = (data+10)%10;
		}
		else
		{
			borrow = 0;
			(*tail1)->data = (data)%10;
		}

                (*tail1) = (*tail1)->prev;
        }

	//Check if the result was the operation was supposed to be a negative value and change result into a negative number
	if(neg)
	{
		dlist *temp = *head1;

		while(temp->data == 0)
		{
			temp = temp->next;
		}

		(temp)->data = (temp)->data * -1;
	}

	*tail1 = temp1 , *tail2 = temp1;

	return 0;
}

/*----------------------------------------------------------------
 * FUNCTION:    mul
 * PURPOSE:     multiply data present in both double linked lists and store it back into the result Double linked list
 * PARAMETERS:  **head1 - pointer to the pointer to the first Node of the first Linked list
                **tail1 - pointer to the pointer to the last Node of the first Linked list
                **tail2 - pointer to the pointer to the last Node of the second Linked list
 * RETURNS:     0 if operation was completed successfully
 -----------------------------------------------------------------*/
int mul(dlist **head1 , dlist **tail1 , dlist **tail2)
{

	dlist *temp1 = *tail1 , *temp2 = *tail2;

	dlist *rtail = NULL , *rhead = NULL , *rtemp = NULL;
	rtemp = rtail ;

	int carry = 0;
	int count = 0;

	//Traverse through List 2
	while(temp2 != NULL)
	{
		count++;

		//Traverse through List 1
		while(temp1 != NULL)
		{
			int pro = ((temp1->data) * (temp2->data) + carry);

			//If there was not enough nodes in the result list create a new node and insert the value
			if(rtemp == NULL)
			{
				insert_first(&rhead,&rtail,(pro)%10);
				rtemp = rhead;
				carry = (pro)/10;
			}
			//If there were enough nodes add the new value with the pre-existing value
			else
			{
				int sum = ((rtemp)->data + pro);
				rtemp->data = sum % 10;
				carry = sum/10;
			}

			temp1 = temp1->prev;
			rtemp = rtemp->prev;

			//Check if there is an extra carry after list 1 ended
			if(temp1 == NULL)
			{
				while(carry)
				{
					//If there was not enough nodes in the result list create a new node and insert the value
					if(rtemp == NULL)
					{
						insert_first(&rhead,&rtail,carry%10);
						rtemp = rhead;
						carry = carry/10;
					}
					//If there were enough nodes add the new value with the pre-existing value
					else
					{
						int n_carry = rtemp->data + carry;
						rtemp->data = n_carry%10;
						carry = n_carry/10;
						rtemp = rtemp->prev;
					}
				}
			}
		}

		//Update pointers
		temp1 = *tail1;
		rtemp = rtail;

		//Add an offset to the result list pointer
		for(int i = 0 ; i < count ; i++)
		{
			rtemp = rtemp->prev;
		}

		temp2 = temp2->prev;
		carry = 0;
	}

	*head1 = rhead;
	*tail1 = rtail;

	return 0;
}

/*----------------------------------------------------------------
 * FUNCTION:    cmp
 * PURPOSE:     Compare the data present in the first list and the second list
 * PARAMETERS:  *head1 - pointer to the pointer to the first Node of the first Linked list
                *head2 - pointer to the pointer to the first Node of the second Linked list
 * RETURNS:     0 if both lists have the same value
		-1 if the second list has a larger value
		1 if the first list has a larger value
 -----------------------------------------------------------------*/
int cmp(dlist *head1 ,dlist *head2)
{
	int count1 = 0 , count2 = 0;

	dlist *temp1 = head1 , *temp2 = head2;

	//Get count of nodes in list 1
	while(temp1)
	{
		count1++;
		temp1 = temp1->next;
	}

	//Get count of node in list 2
	while(temp2)
	{
		count2++;
		temp2 = temp2->next;
	}

	//compare the number of nodes in Link1 and Link2
	if(count1 < count2)
	{
		return -1;
	}
	else if(count1 > count2)
	{
		return 1;
	}
	else
	{
		//If node count is same compare the value stored in the list
		while(head1 != NULL && (head1->data == head2->data))
		{
			head1 = head1->next;
			head2 = head2->next;
		}

		if(head1 && head2)
		{
			return (head1->data - head2->data);
		}
		else if(head1)
		{
			return 1;
		}
		else if(head2)
		{
			return -1;
		}
		else
		{
			return 0;
		}

	}

}


/*----------------------------------------------------------------
 * FUNCTION:    divi
 * PURPOSE:     divi data present in both double linked lists and store it back into the first Double linked list
 * PARAMETERS:  **head1 - pointer to the pointer to the first Node of the first Linked list
                **tail1 - pointer to the pointer to the last Node of the first Linked list
		**head2 - pointer to the pointer to the first Node of the second Linked list
                **tail2 - pointer to the pointer to the last Node of the second Linked list
 * RETURNS:     0 if operation was completed successfully
 -----------------------------------------------------------------*/
int divi(dlist **head1 , dlist **tail1 , dlist **head2 , dlist **tail2)
{
	int count = 0;

	dlist *rhead = NULL , *rtail = NULL , *ahead = NULL , *atail = NULL;

	//Create lists for result
	insert_first(&rhead,&rtail,0);
	insert_first(&ahead,&atail,1);

	//Perform Sub operation as long as operand1 is larger than operator2
	while(*head1 != NULL && cmp(*head1 , *head2) >= 0)
	{
		dlist *temp2 = *tail2;

		//Sub operation
		sub(head1,tail1,&temp2,0);

		//Increment result list
		add(&rhead,&rtail,&atail);

		dlist *temp = *head1;

		//Skip leading Zeros
                while(temp != NULL && temp->data == 0 && temp->next != NULL)
                {
                        temp = temp->next;
                }

		*head1 = temp;
	}

	//Restore pointers
	*head1 = rhead;
	*tail1 = rtail;

	return 0;
}

/*----------------------------------------------------------------
 * FUNCTION:    perform_operation
 * PURPOSE:     Perform the operation Instructed by the user
 * PARAMETERS:  input - array of character pointers holding both the operands and the operator
 * RETURNS:     head pointer of the result double linked list
 -----------------------------------------------------------------*/
dlist *perform_operation(char *input[])
{
	//Retrieve the operator
	char op = input[2][0];

	//Create pointers for both operands
	dlist *head1 , *tail1 , *head2 , *tail2;
	head1 = tail1 = head2 = tail2 = NULL;

	//Skip leading zeros in operand1
	while(*(input[1]) == '0')
	{
		(input[1])++;
	}

	//Skip leading zeros in operand2
	while(*(input[3]) == '0')
	{
		(input[3])++;
	}

	//Create lists for both operands
	create_dlist(input[1],&head1,&tail1);
	create_dlist(input[3],&head2,&tail2);

	switch(op)
	{
		case '+' : 	//Add operation
				add(&head1,&tail1,&tail2);
				return head1;
				break;

		case '-' : {
			   	//If operand 2 is bigger than operand 1
				if(strlen(input[3]) > strlen(input[1]))
			   	{
			   		sub(&head2,&tail2,&tail1,1);
			   		return head2;
			   	}
				//If operand 2 is greater then operand 1 and both are of same length
			   	else if((strcmp(input[1],input[3]) < 0) && (strlen(input[3]) == strlen(input[1])))
			   	{
					sub(&head2,&tail2,&tail1,1);
			   		return head2;
			   	}
				//If operand 1 is greater then operand 2
			   	else
			   	{
			   		sub(&head2,&tail1,&tail2,0);
					return head1;
			   	}
		  	   	break;
			   }

		case 'x' : //Swapping operand 1 and operand 2 for better time complexity
			   if(strlen(input[3]) > strlen(input[1]))
			   {
			   	mul(&head2,&tail2,&tail1);
			   	return head2;
			   }
			   else
			   {
				mul(&head1,&tail1,&tail2);
				return head1;
		 	   }
			  break;

		case '/' : //If second operand is 0
			   if(strlen(input[3]) == 0)
			   {
				fprintf(stderr,"Cannot Divide by 0\n");
				exit(0);
			   }
			   //If second operand is larger than first operand or first operand is 0
			   else if((strlen(input[3]) > strlen(input[1])) || strlen(input[1]) == 0 || (strcmp(input[1],input[3]) < 0 && (strlen(input[3]) == strlen(input[1]))))
		   	   {
				printf("0\n");
			   	exit(0);
			   }
			   //If both operands are equal
			   else if(strcmp(input[1],input[3]) == 0)
			   {
				printf("1\n");
				exit(0);
			   }
			   //If first operand is larger than operand 2
			   else
			   {
				divi(&head1,&tail1,&head2,&tail2);
		 	   	return head1;
			   }
			   break;

		default :  fprintf(stderr,"Invalid Operator\n");
			   exit(0);
	}

}

/*----------------------------------------------------------------
 * FUNCTION:    print_list
 * PURPOSE:     Print the double linked list
 * PARAMETERS:  *head - pointer to the pointer to the first Node of the Linked list
 * RETURNS:     0 if operation was completed successfully
 -----------------------------------------------------------------*/
int print_list(dlist *head)
{

	//If list is empty
	if(head == NULL)
	{
		printf("0");
	}

	//Skip leading Zeros
	while(head != NULL && head->data == 0)
	{
		head = head->next;

		if(head == NULL)
		{
			printf("0\n");
			return 0;
		}
	}

	//Print List
	while(head != NULL)
	{
		printf("%d",head->data);
		head = head->next;
	}

	printf("\n");

	return 0;
}
