/*----------------------------------------------------------------
 * FILE:        apc.h
 * AUTHOR:      Harsha S
 * PURPOSE:     Contains all the function Prototypes
 * DATE:        July 10, 2025
 -----------------------------------------------------------------*/

#ifndef APC_C
#define APC_C

#include <stdio.h>
#include <string.h>
#include <stdlib.h>


//Structure for Double Linked list Node
typedef struct Dlist
{
	int data;
	struct Dlist *next;
	struct Dlist *prev;
}dlist;


//Function Prototypes
int insert_first(dlist **, dlist ** , int );
int create_dlist(char * , dlist ** , dlist **);

int add(dlist ** , dlist ** , dlist ** );
int sub(dlist ** , dlist ** , dlist ** , int );
int mul(dlist ** , dlist ** , dlist **);

int cmp(dlist * , dlist *);
int divi(dlist ** , dlist ** , dlist ** , dlist **);

dlist *perform_operation(char *[]);

int print_list(dlist *);

#endif
