/*----------------------------------------------------------------
 * FILE:        main.c
 * AUTHOR:      Harsha S
 * PURPOSE:     Performs the operation
 * DATE:        August 4, 2025
 -----------------------------------------------------------------*/

//Contains function prototypes and Double Linked list structure
#include "apc.h"

int main(int count , char *input[])
{

	//If incorrect arguements were passed
	if(count < 4 || !strcmp(input[1],"--help"))
	{
		fprintf(stderr,"Type ./a.out operand1 operator operand2\n");
		return 0;
	}

	//Performing Operation
	dlist *result = perform_operation(input);

	//Printing List after Operation got completed
	print_list(result);

	return 0;

}
