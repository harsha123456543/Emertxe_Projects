
/*----------------------------------------------------------------
 * FILE:        main.C
 * AUTHOR:      Harsha S
 * PURPOSE:     Controls all the operations
 * DATE:        September 20, 2025
 -----------------------------------------------------------------*/

#include "Create_RBBST.h"

//Controls all the operations
int main()
{

	RBTree tree;

	char choice = 0;
	int value = 0;
	int status = 0;
	TreeNode* temp = NULL;

	while(1)
	{

		cout << endl << "Select the operation to perform"<<endl;
		cout << "1. Insert Element\n2. View Tree\n3. Search Element\n4. Find Min\n5. Find Max\n6. Delete Min\n7. Delete Max\n8. Delete Element\ne. exit\n\n";
		cin >> choice;

		switch(choice)
		{
			case '1' :	cout << "Enter the value to insert ";
					cin >> value;
					status = tree.insert(value);

					if(status == SUCCESS) cout << "Successfully Inserted Element"<<endl;
					else cout << "Failed to insert Element"<<endl;

					break;

			case '2' :	if(tree.display() == EMPTY)
						cout << "The Tree is Empty" << endl;
					break;

			case '3' :	cout << "Enter the value to search for ";
					cin >> value;

					if(tree.search(value) != NULL)
					{
						cout << "Element found"<<endl;
					}
					else
					{
						cout << "Element not found"<<endl;
					}

					break;

			case '4' :	if((temp = tree.find_min()) != NULL)
					{
						cout << "min -> " << temp->get_val();
					}
					else
					{
						cout << "Tree is Empty" << endl;
					}
					break;

			case '5' : 	if((temp = tree.find_max()) != NULL)
					{
						cout << "max -> " << temp->get_val();
					}
					else
					{
						cout << "Tree is Empty" << endl;
					}
					break;

			case '6' :	status = tree.delete_min();

					if(status == SUCCESS)
					{
						cout << "Successfully deleted minimum value" << endl;
					}
					else
					{
						cout << "Tree is Empty";
					}

					break;

			case '7' :	status = tree.delete_max();

					if(status == SUCCESS)
					{
						cout << "Successfully deleted maximum value" << endl;
					}
					else
					{
						cout << "Tree is Empty" << endl;
					}
					break;

			case '8' : 	cout << "Enter the value to delete ";
					cin >> value;

					if((status = tree.delet(value)) == SUCCESS)
					{
						cout << "Successfully deleted element" << endl;
					}
					else if(status == EMPTY)
					{
						cout << "Tree is Empty" << endl;
					}
					else
					{
						cout << "Element not Found" << endl;
					}
					break;

			case 'e' : 	cout << "Exiting" << endl;
					return 0;

			default : 	cout << "Invalid input "<<endl;
		}


	}


	return 0;

}
