
/*----------------------------------------------------------------
 * FILE:        Create_RBBST.C
 * AUTHOR:      Harsha S
 * PURPOSE:     Contains all the function definitions
 * DATE:        September 20, 2025
 -----------------------------------------------------------------*/

#include "Create_RBBST.h"

//Constructor to create node
TreeNode :: TreeNode(int val)
{

	this->val = val;
	left = right = parent = nullptr;

	color = red;
}

//Constructor to initialize RB Tree root node
RBTree :: RBTree()
{
	root = nullptr;
}

//Function to get value of a node
int TreeNode :: get_val()
{
	return val;
}

//Function to insert a new node into the RB Tree
int RBTree :: insert(int val)
{

	TreeNode *node = new TreeNode(val);

	TreeNode *curr = root , *prev = nullptr;

	while(curr != NULL)
	{
		prev = curr;

		if(curr->val < val)
		{
			curr = curr->right;
		}
		else
		{
			curr = curr->left;
		}
	}

	if(prev == NULL)
	{
		root = node;
	}
	else
	{
		node->parent = prev;

		if(val < prev->val)
		{
			prev->left = node;
		}
		else
		{
			prev->right = node;
		}
	}

	fix_insert(node);

	return SUCCESS;
}

//Function to fix violations caused due to previous insertion
int RBTree :: fix_insert(TreeNode *node)
{

	TreeNode* gparent = NULL , *uncle = NULL;

	while(node->parent && node->parent->color == red)
	{


		if(node->parent && node->parent->parent) gparent = node->parent->parent;

		if(gparent)
		{
			if(gparent->left == node->parent) uncle = gparent->right;
			else uncle = gparent->left;
		}


		if(gparent && gparent->left == node->parent)
		{
			if(uncle && uncle->color == red)
			{

				node->parent->color = black;
				uncle->color = black;
				gparent->color = red;

				node = gparent;
				continue;
			}
			else if(!uncle || uncle->color == black)
			{

				if(node->parent->right == node)
				{

					node = node->parent;
					rotate_left(node);

				}

				node->parent->color = black;
				gparent->color = red;

				rotate_right(gparent);

			}


		}
		else if(gparent && gparent->right == node->parent)
		{

                        if(uncle && uncle->color == red)
                        {

                                node->parent->color = black;
                                uncle->color = black;
                                gparent->color = red;

                                node = gparent;
                                continue;
                        }

                        else if(!uncle || uncle->color == black)
                        {

                                if(node->parent->left == node)
                                {

					node = node->parent;
                                        rotate_right(node);

                                }


				node->parent->color = black;
				gparent->color = red;

				rotate_left(gparent);

                        }


		}
		else
		{
			break;
		}


	}


	root->color = black;

	return SUCCESS;

}

//Function to perform Left rotation of a node
int RBTree :: rotate_left(TreeNode *node)
{

	if(!node || !(node->right)) return FAILED;

	TreeNode *y = node->right;
        node->right = y->left;

	if(y->left)
	y->left->parent = node;

	y->parent = node->parent;

	if(node->parent == NULL)
	{
		root = y;
		y->parent = NULL;
	}
	else if(node == node->parent->left)
	{
		node->parent->left = y;
	}
	else
	{
		node->parent->right = y;
	}

	y->left = node;
	node->parent = y;

	return SUCCESS;

}

//Function to perform Right Rotation of a Node
int RBTree :: rotate_right(TreeNode *node)
{

	if(!node || !(node->left)) return FAILED;

	TreeNode *y = node->left;
        node->left = y->right;

        if(y->right)
        y->right->parent = node;

        y->parent = node->parent;

        if(node->parent == NULL)
        {
                root = y;
		y->parent = NULL;
        }
        else if(node == node->parent->left)
        {
                node->parent->left = y;
        }
        else
        {
                node->parent->right = y;
        }

        y->right = node;
        node->parent = y;


	return SUCCESS;
}

//Function to search for a node with a specific value
TreeNode* RBTree :: search(int val)
{

	if(root == NULL)
	{
		return NULL;
	}

	TreeNode *temp = root;

	while(temp != NULL)
	{
		if(temp->val == val)
		{
			return temp;
		}
		else if(temp->val < val)
		{
			temp = temp->right;
		}
		else
		{
			temp = temp->left;
		}
	}

	return NULL;
}

//Function to find minimum value of the RB Tree
TreeNode* RBTree :: find_min()
{

	if(root == NULL)
	{
		return NULL;
	}

	TreeNode* temp = root;

	while(temp->left)
	{
		temp = temp->left;
	}

	return temp;
}

//Function to delete minimum value
int RBTree :: delete_min()
{
	TreeNode *min_node = find_min();

	delet(min_node->val);

	return SUCCESS;
}

//Function to find maximum value of the RB Tree
TreeNode* RBTree :: find_max()
{

	if(root == NULL)
	{
		return NULL;
	}

	TreeNode* temp = root;

	while(temp->right)
	{
		temp = temp->right;
	}

	return temp;
}

//Function to delete maximum value
int RBTree :: delete_max()
{

	TreeNode *max_node = find_max();

	delet(max_node->val);

	return SUCCESS;

}

//Function to preform transplantion of a node
int RBTree :: transplant(TreeNode *u , TreeNode *v)
{

	if(u->parent == NULL)
	{
		root = v;
	}
	else if(u == u->parent->left)
	{
		u->parent->left = v;
	}
	else
	{
		u->parent->right = v;
	}

	if(v != NULL)
		v->parent = u->parent;

	return SUCCESS;

}

//Function to find min of a sub tree
TreeNode* RBTree :: minimum(TreeNode *node)
{

	while(node->left != NULL)
	{

		node = node->left;

	}

	return node;
}

//Function to delete a node with a specific value
int RBTree :: delet(int val)
{

	TreeNode *node = search(val);
	TreeNode *rep = NULL;

	if(node == NULL) return FAILED;

	TreeNode *og = node;
	int og_color = node->color;

	if(node->left == NULL)
	{

		rep = node->right;
		transplant(node,node->right);

	}
	else if(node->right == NULL)
	{

		rep = node->left;
		transplant(node,node->left);
	}
	else
	{

		og = minimum(node->right);
		og_color = og->color;

		rep = og->right;

		if(og->parent == node)
		{
			if(rep)
				rep->parent = og;
		}
		else
		{
			transplant(og,og->right);
			og->right = node->right;
			og->right->parent = og;
		}

		transplant(node,og);
		og->left = node->left;
		og->left->parent = og;
		og->color = node->color;
	}

	if(og_color == black)
	{
		fix_delete(rep);
	}

	delete node;

	return SUCCESS;
}

//Function to fix violations caused due to previous deletion
int RBTree :: fix_delete(TreeNode *rep)
{

	TreeNode *sib = NULL;

	while(rep != root && (rep == NULL || rep->color == black))
	{

		if(rep == NULL) break;
		if(rep->parent == NULL) break;

		if(rep->color == black)
		{
			if(rep->parent->left == rep)
			{

				sib = rep->parent->right;

				if(sib && sib->color == red)
				{
					sib->color = black;
					rep->parent->color = red;

					rotate_left(rep->parent);

					sib = rep->parent->right;

				}
				if(sib == NULL || (sib->color == black))
				{

					if( (sib->left == NULL || sib->left->color == black) && (sib->right == NULL || sib->right->color == black) )
					{
						sib->color = red;
						rep = rep->parent;
					}
					else if(sib && (sib->left && sib->left->color == red) && (sib->right == NULL || sib->right->color == black) )
					{

						sib->left->color = black;
						sib->color = red;

						rotate_right(sib);

						sib = rep->parent->right;
					}
					else if(sib && (sib->right && sib->right->color == red))
					{

						sib->color = sib->parent->color;
						rep->parent->color = black;
						sib->right->color = black;

						rotate_left(rep->parent);

						rep = root;
					}
				}

			}

			else if(rep->parent->right == rep)
                	{

                        	sib = rep->parent->left;

                        	if(sib && sib->color == red)
                        	{
                                	sib->color = black;
                                	rep->parent->color = red;

                                	rotate_right(rep->parent);

					sib = rep->parent->left;
				}
                        	else if(sib == NULL || (sib->color == black))
                        	{

                                	if( (sib->left == NULL || sib->left->color == black) && (sib->right == NULL || sib->right->color == black) )
                                	{
                                        	sib->color = red;
                               	         	rep = rep->parent;
                                	}
                                	else if( (sib->right && sib->right->color == red) && (sib->left == NULL || sib->left->color == black) )
                                	{

                                        	sib->right->color = black;
                                        	sib->color = red;

                                        	rotate_left(sib);

						sib = rep->parent->left;
                                	}
                                	else if((sib->left && sib->left->color == red))
                                	{

                                        	sib->color = sib->parent->color;
                                        	rep->parent->color = black;
                                        	sib->left->color = black;

                                        	rotate_right(rep->parent);

						rep = root;
				 	}
                        	}
			}
		}

	}

	if(rep)
		rep->color = black;

	if(root)
		root->color = black;

	return SUCCESS;

}

//Function to display the entire tree
int RBTree :: display()
{

	if(root == NULL)
	{
		return EMPTY;
	}

	queue<TreeNode *> nodes;

	nodes.push(root);

	cout << endl << "-----------------------------"<<endl;

	while(!nodes.empty())
	{

		int size = nodes.size();


		for(int i = 0 ; i < size ; i++)
		{
			if(nodes.front())
			{
				cout << nodes.front()->val << " " << ((nodes.front()->color == red) ? 'R' : 'B')  << " ";
			}
			else
			{
				cout << " NULL ";
				nodes.pop();
				continue;
			}

			if((nodes.front())->left || (nodes.front())->right)
			{
				nodes.push((nodes.front())->left);
				nodes.push((nodes.front())->right);
			}

			nodes.pop();

		}

		cout << endl;

	}

        cout << "-----------------------------"<<endl;
	cout << endl;

	return SUCCESS;
}











