
/*----------------------------------------------------------------
 * FILE:        Create_RBBST.h
 * AUTHOR:      Harsha S
 * PURPOSE:     Contains all the classes and function prototypes
 * DATE:        September 20, 2025
 -----------------------------------------------------------------*/


#ifndef CREATE_RBBST_H
#define CREATE_RBBST_H

#include <bits/stdc++.h>

#define EMPTY -1
#define SUCCESS 0
#define FAILED 1

using namespace std;

enum Color {red , black};

//Class for Tree Nodes operations
class TreeNode
{
	int val;

	class TreeNode *left;
	class TreeNode *right;
	class TreeNode *parent;

	Color color;

	public:

	TreeNode(int );

	int get_val();

	friend class RBTree;
};

//Class for the Red Black tree operations
class RBTree
{

	TreeNode *root;

	int rotate_left(TreeNode *);
	int rotate_right(TreeNode *);
	int fix_insert(TreeNode *);
	int fix_delete(TreeNode *);

	TreeNode* minimum(TreeNode *);

	public:

	RBTree();

	int insert(int );

	TreeNode* search(int );

	int delet(int );

	int transplant(TreeNode * , TreeNode *);

	TreeNode* find_min();
	int delete_min();

	TreeNode* find_max();
	int delete_max();

	int display();
};

#endif
