/*----------------------------------------------------------------
 * FILE:        main.c
 * AUTHOR:      Harsha S
 * PURPOSE:     Controls all the operations
 * DATE:        September 25, 2025
 -----------------------------------------------------------------*/

#include "editor.h"

//Main function to control operations
int main(int argc , char *argv[])
{

	char choice = 0 , save_option = 0;
	char string[1024] = {0} , filename[100] = {0};

	int line = 0 , file = 1;

	ListNode *head = NULL;

	FILE *fp = NULL;

	if(argc > 1)
	{
                printf("\nSuccessfully openend file -> %s\n\n",argv[file]);
		fp = fopen(argv[file],"r");
	}

        if(fp != NULL)
        {
                load(&head,fp);
        }

	if(argc > 1 && fp == NULL)
	{
		fp = fopen(argv[file],"w");
	}

	while(1)
	{

		printf("Select the operation to perform\n");
		printf("1. Insert at the End\n2. Insert at Line\n3. Display Content\n4. Display Line\n5. Edit Line\n6. Append data to line\n7. Delete Line\n8. Delete Content\n9. Open next file\ns. Save Content\ne. Exit\n\n");

		scanf(" %c",&choice);

		switch(choice)
		{
			case '1' :	//Insert at End
					printf("Enter the data : \n");
					scanf(" %[^\n]",string);

					if(insert(&head,string) == SUCCESS)
					{
						printf("\nSuccessfully inserted element\n\n");
					}
					else
					{
						printf("\nFailed to insert\n\n");
					}
					break;

			case '2' :	//Insert at a specific position
                                        printf("Enter the data : \n");
                                        scanf(" %[^\n]",string);
					printf("Enter the Line number : \n");
					scanf("%d",&line);

					if(insert_at(&head,string,line) == SUCCESS)
                                        {
					       printf("\nSuccessfully inserted element\n\n");
                                        }
                                        else
                                        {
                                                printf("\nFailed to insert\n\n");
                                        }
					break;

			case '3' :	//Display Entire database
					if(display(head) == FAILED)
						printf("\nDatabase is Empty\n\n");
					break;

			case '4' :	//Display specific database
					printf("Enter the line to display : \n");
					scanf(" %d",&line);

					if(display_line(head,line) == SUCCESS)
					{
						printf("\nSuccessfully found data\n\n");
					}
					else
					{
						printf("\nCould not find data\n\n");
					}
					break;

			case '5' :	//Edit Specific line
					printf("Enter the line number to edit the data on : \n");
					scanf("%d",&line);

					if(display_line(head,line) == SUCCESS)
					{
						printf("Enter the new data : \n");
						scanf(" %[^\n]",string);

						edit_line(head,line,string);
					}
					else
					{
						printf("Line does not exist\n");
					}
					break;

			case '6' :	//Append data to specific line
					printf("Enter the line number to append the data to : \n");
					scanf("%d",&line);

					if(display_line(head,line) == SUCCESS)
					{
						printf("Enter the data to append : \n");
						scanf(" %[^\n]",string);

						append_data(head,line,string);
					}
					else
					{
						printf("Line does not exist\n");
					}
					break;

			case '7' :	//Delete line
					printf("Enter the line to delete : \n");
					scanf(" %d",&line);

					if(delet(&head,line) == SUCCESS)
					{
						printf("\nSuccessfully deleted line\n\n");
					}
					else
					{
						printf("\nFailed to delete line\n\n");
					}
					break;

			case '8' :	//Delete Database
					delete_all(&head);
					printf("\nSuccessfully deleted data\n\n");
					break;


			case 's' :	//Save in file

					if(argc > 1)
					{
						printf("\nSave in %s ?\n 1 -> yes 0 -> No\n\n",argv[file]);
						scanf(" %c",&save_option);
					}
					if(!save_option)
					{
						printf("Enter the name of the file to store the data in : \n");
						scanf(" %s",filename);
					}
					else
					{
						strcpy(filename,argv[file]);
					}

					fp = fopen(filename,"w");

					if(save(head,fp) == SUCCESS)
					{
						printf("\nSuccessfully saved contents in the file -> %s\n\n",filename);
					}
					else
					{
						printf("\nFailed to save contents in the file -> %s\n\n",filename);
					}
					break;

			case '9' :	//Open next file
					if(file < argc)
						file++;

					if(file < argc)
					{
						delete_all(&head);

						fp = fopen(argv[file],"r");

						if(fp != NULL)
						{
							load(&head,fp);
						}

						if(fp == NULL)
						{
							fp = fopen(argv[file],"w");
						}

						printf("\nSuccessfully opened next file -> %s\n\n",argv[file]);

					}
					else
					{
						printf("\nError : No more files to open\n\n");
					}
					break;

			case 'e' :	//Exit or move to next file
					printf("\nExiting\n\n");
					return 0;


			default : 	printf("\nInvalid Input\n\n");
					break;
		}


	}


	return 0;

}
