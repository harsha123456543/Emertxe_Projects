/*----------------------------------------------------------------
 * FILE:        editor.c
 * AUTHOR:      Harsha S
 * PURPOSE:     Contains all the function definitions
 * DATE:        September 25, 2025
 -----------------------------------------------------------------*/

#include "editor.h"

int line_count = 0;

//Function to load contents of the file into the database
int load(ListNode **head , FILE *fp)
{

	fseek(fp,0,SEEK_END);

	if(ftell(fp) == 0)
	{
		return SUCCESS;
	}

	fseek(fp,0,SEEK_SET);

	char string[1024] = {0};

	while(fscanf(fp,"%[^\n]\n",string) == 1)
	{
		insert(head,string);
		line_count++;
	}


	return SUCCESS;
}

//Function to insert new line into the database
int insert(ListNode** head , char *string)
{

	ListNode* new = malloc(sizeof(ListNode));

	if(new == NULL) return FAILED;

	ListNode* temp = *head;

	strcpy(new->string,string);
	new->next = NULL;

	line_count++;

	if(*head == NULL)
	{
		*head = new;
		return SUCCESS;
	}

	while(temp->next != NULL)
	{
		temp = temp->next;
	}

	temp->next = new;

	return SUCCESS;
}

//Function is insert at a specific position in the database
int insert_at(ListNode **head , char * string , int line)
{

	if(line > 0 && (line <= line_count + 1 ))
	{
		return FAILED;
	}

        ListNode* new = malloc(sizeof(ListNode));

        if(new == NULL) return FAILED;

        ListNode* temp = *head;

        strcpy(new->string,string);
        new->next = NULL;

        line_count++;

	if(line == 1)
	{
		*head = new;
		new->next = temp;

		return SUCCESS;
	}

	for(int i = 2 ; i < line ; i++)
	{
		temp = temp->next;
	}

	new->next = temp->next;
	temp->next = new;

	return SUCCESS;
}

//Function to display a specific line
int display_line(ListNode *head , int line)
{

	if(line_count < line || line < 0)
	{
		return FAILED;
	}

	for(int i = 1 ; i < line ; i++)
	{
		head = head->next;
	}

        printf("\n----------------------------\n");

	printf("%s\n",head->string);

        printf("----------------------------\n\n");

	return SUCCESS;

}

//Function to display the entire Database
int display(ListNode *head)
{
	int count = 1;

	if(head == NULL)	return FAILED;

	printf("\n----------------------------\n");

	while(head)
	{
		printf("%d-> %s\n",count,head->string);
		head = head->next;
		count++;
	}

        printf("----------------------------\n\n");

	return SUCCESS;
}

//Function to edit a specific line
int edit_line(ListNode *head , int line , char *string)
{

	ListNode *temp = head;


	for(int i = 1 ; i < line ; i++)
	{
		temp = temp->next;
	}

	strcpy(temp->string,string);

	return SUCCESS;

}

//Function to append data to end of the line
int append_data(ListNode *head , int line , char *string)
{

        ListNode *temp = head;


        for(int i = 1 ; i < line ; i++)
        {
                temp = temp->next;
        }

	strcat(temp->string," ");
        strcat(temp->string,string);

        return SUCCESS;


}


//Function to delete a line in the database
int delet(ListNode **head , int line)
{

	ListNode *cur = *head , *prev = NULL;

	if(line_count < line)
	{
		return FAILED;
	}

	if(line == 1)
	{
		*head = (*head)->next;
		free(cur);

		return SUCCESS;
	}

	for(int i = 1; i < line ; i++)
	{
		prev = cur;
		cur = cur->next;
	}

	prev->next = cur->next;

	free(cur);

	line_count--;

	return SUCCESS;
}

//Function to delete the entire database
int delete_all(ListNode **head)
{

	while(*head)
	{
		delet(head,1);
	}

	return SUCCESS;

}

//Function to save the database into the file
int save(ListNode *head , FILE *fp)
{

	while(head)
	{

		fprintf(fp,"%s\n",head->string);
		head = head->next;
	}

	fclose(fp);

	return SUCCESS;
}
