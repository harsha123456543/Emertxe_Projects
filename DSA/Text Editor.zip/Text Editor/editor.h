/*----------------------------------------------------------------
 * FILE:        editor.h
 * AUTHOR:      Harsha S
 * PURPOSE:     Contains all the function prototypes
 * DATE:        September 25, 2025
 -----------------------------------------------------------------*/

#ifndef EDITOR_H
#define EDITOR_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define SUCCESS 0
#define FAILED 1

//Linked List Structure
struct Node
{

	char string[1024];
	struct Node *next;

};

typedef struct Node ListNode;

//Function prototypes

int load(ListNode** , FILE *);

int insert(ListNode** , char* );

int insert_at(ListNode ** , char* , int);

int display(ListNode* );

int display_line(ListNode* , int );

int edit_line(ListNode* , int , char* );

int append_data(ListNode* , int , char* );

int delet(ListNode** , int );

int delete_all(ListNode ** );

int save(ListNode* , FILE * );

#endif
