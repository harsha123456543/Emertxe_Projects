/*----------------------------------------------------------------
 * FILE:        server.c
 * AUTHOR:      Harsha S
 * PURPOSE:     Control All Server Operations
 * DATE:        October 9, 2025
 -----------------------------------------------------------------*/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <sys/select.h>
#include <unistd.h>

#define MAX_FD 1024

//Client Info
typedef struct
{
	int sockfd;
	char username[32];
	char password[32];
}cl;

//Main function to control all the operations
int main()
{

	cl clients[20];

	int user_count = 0;

	int family = AF_INET;
	int type = SOCK_STREAM;

	//Create Socket
	int sock = socket(family,type,0);

	struct sockaddr_in sck;

	sck.sin_family = AF_INET;
	sck.sin_port = htons(2000);
	sck.sin_addr.s_addr = inet_addr("192.168.1.11");

	//Bind socket to Specific IP
	bind(sock,(const struct sockaddr *)&sck,sizeof(sck));

	printf("Server Successfully Created IP : %s , Port : %d\n\n",inet_ntoa(sck.sin_addr),htons(sck.sin_port));

	//Listen for clients
	listen(sock,20);

	//Set of socket FDs
	fd_set active_fd , read_fd;

	FD_ZERO(&active_fd);
	FD_ZERO(&read_fd);

	FD_SET(sock,&active_fd);

	while(1)
	{

		read_fd = active_fd;

		//Check for active connections
		select(MAX_FD,&read_fd,NULL,NULL,NULL);

		for(int i = 0 ; i < MAX_FD ; i++)
		{
			if(FD_ISSET(i,&read_fd))
			{

				//Incase of new client
				if(i == sock)
				{
					char username[100], password[100], option[2] , retbuf[2];

					struct sockaddr_in client;

					int size = sizeof(client);

					int exist = 0;

					int new = accept(sock,(struct sockaddr *)&client,&size);

					printf("\nNew Connection Attempt Client IP : %s , Port : %d\n",inet_ntoa(client.sin_addr),ntohs(client.sin_port));

					//Collect Client Data
					recv(new,option,sizeof(option),0);
					recv(new,username,sizeof(username),0);
					recv(new,password,sizeof(password),0);

					//Client Login / Register
					for(int i = 0 ; i < user_count ; i++)
					{
						if(!strcmp(username,clients[i].username) && option[0] != '2')
						{
							if(!strcmp(password,clients[i].password))
							{
								retbuf[0] = '0';
								send(new,retbuf,sizeof(retbuf),0);
								exist = 1;
								printf("User : %s Logged In\n",username);
							}
							else
							{
								retbuf[0] = '3';
								send(new,retbuf,sizeof(retbuf),0);
								printf("Connection Failed\n");
								continue;
							}
						}
						else if(!strcmp(username,clients[i].username) && option[0] == '2')
						{
							retbuf[0] = '2';
							send(new,retbuf,sizeof(retbuf),0);
							printf("Connection Failed\n");
							continue;
						}
					}

					if(!exist && option[0] != '1')
					{
                                                printf("User : %s Logged In\n",username);

						retbuf[0] = '4';
						send(new,retbuf,sizeof(retbuf),0);

						clients[user_count].sockfd = new;
						strcpy(clients[user_count].username,username);
						strcpy(clients[user_count].password,password);

						user_count++;

					}
					else if(!exist && option[0] == '1')
					{
						retbuf[0] = '1';
						send(new,retbuf,sizeof(retbuf),0);
						printf("Connection Failed\n");
						continue;
					}


					char join[200];

					sprintf(join,"\n[SERVER] %s joined the server\n",username);
					printf("Client Count : %d\n",user_count);

					for(int k = 0 ; k < user_count ; k++)
					{
						send(clients[k].sockfd,join,strlen(join)+1,0);
					}

					FD_SET(new,&active_fd);

				}

				//Pr-existing Client

				else
				{
					char buffer[100];
					int n = 0;


					for(int j = 0 ; j < user_count ; j++)
					{
						if(i == clients[j].sockfd)
						{
							if((n = recv(i,buffer,sizeof(buffer),0)) <= 0)
							{
								close(i);
								FD_CLR(i,&active_fd);

								char message[100];

								sprintf(message,"\nUser %s disconnected\n\n",clients[j].username);

								printf("%s",message);

								for(int k = j ; k < user_count ; k++)
								{
									clients[k] = clients[k+1];
								}


								user_count--;

                                                                for(int k = 0 ; k < user_count ; k++)
                                                                {
                                                                    	int fd = clients[k].sockfd;

                                                                        send(fd,message,strlen(message)+1,0);
                                                                }

							}
							else
							{
								buffer[n] = 0;

								char msg[1024] = {0};

								//Message Sent from client
								if(!strncmp(buffer,"ALL:",4))
								{

									sprintf(msg,">[%s] %s",clients[j].username,buffer+4);

									for(int k = 0 ; k < user_count ; k++)
									{

										int fd = clients[k].sockfd;

										if(fd != clients[j].sockfd)
										{

											send(fd,msg,strlen(msg)+1,0);
										}

									}
								}
								else if(!strncmp(buffer,"TO:",3))
								{

									char *p = strchr(buffer+3,':');

									if(p)
									{
										*p = '\0';
										char *target = buffer+3;
										char *mes = p+1;

										int found = 0;

										for(int k = 0 ; k < user_count ; k++)
										{
											if(!strcmp(clients[k].username,target))
											{
												sprintf(msg,"[DM from %s] %s",clients[j].username,mes);
												send(clients[k].sockfd,msg,strlen(msg)+1,0);
												found = 1;
												break;
											}

										}

										if(!found)
										{
											sprintf(msg,"[SERVER] user %s not found",target);
											send(clients[j].sockfd,msg,strlen(msg)+1,0);
										}
									}

								}
								else
								{

									char help[] = "Invalid message use ALL:<message> or TO:<user><message>\n";
									send(clients[j].sockfd,help,strlen(help)+1,0);
								}
							}
						}
					}
				}
			}
		}
	}

	return 0;

}
