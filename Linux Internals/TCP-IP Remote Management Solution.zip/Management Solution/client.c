/*----------------------------------------------------------------
 * FILE:        client.c
 * AUTHOR:      Harsha S
 * PURPOSE:     Control All Client operations
 * DATE:        October 26, 2025
 -----------------------------------------------------------------*/


#include <stdio.h>
#include <stdlib.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netinet/ip.h>
#include <string.h>

//Main Function that controls all the operations of the Client
int main()
{

	//Creating a socket
	int sock = socket(AF_INET , SOCK_STREAM , 0);

	struct sockaddr_in sck;

	sck.sin_family = AF_INET;

	short port;
	char ip[33] , operation[100] , response[100];

	printf("Enter the IP Address : ");
	scanf("%s",ip);

	sck.sin_addr.s_addr = inet_addr(ip);

	printf("Enter the Port Number : ");
	scanf("%hd",&port);

	sck.sin_port = htons(port);

	//Connect Client to Server
	if(connect(sock , (const struct sockaddr*)&sck , sizeof(sck)) < 0)
	{

		printf("Failed to connect to server\n");
		return 0;

	}

	printf("Connected to Server\nType help to get supported commands\n");

	int count = 0;
	char commands[100][50];

	while(1)
	{

		//Read instructions from the user
		printf("Client]  ");
		scanf(" %[^\n]",operation);

		strcpy(commands[count++],operation);

		if(!strcmp(operation,"help"))
		{
			printf("\nget-mem <process-name> 		: 	Gets memory usage of given process\n");
			printf("get-cpu-usage <process-name> 	: 	Gets the CPU usage of a given process\n");
			printf("get-ports-used <process-name> 	: 	Fetch the Socket ports used by the process\n");
			printf("get-open-fd <process-name> 	: 	Fetch the open File descriptors of a given process\n");
			printf("kill <process-name> 		: 	Kill the given process\n");
			printf("history 			:	show the commands history\n");
			printf("help 				: 	shows this output\n");
			printf("exit 				: 	Terminate Client\n\n");
		}
		else if(!strcmp(operation,"exit"))
		{

			printf("Exiting\n");
			return 0;

		}
		else if(!strcmp(operation,"history"))
		{

			printf("\n");

			for(int i = 0 ; i < count - 1 ; i++)
			{
				printf("%s\n",commands[i]);
			}

			printf("\n");

		}

		//Send command to server and collect response from server
		else
		{
			int n = send(sock , operation , strlen(operation) + 1 , 0);

			if(n > 0)
				printf("Message Sent to Server\n");

			n = recv(sock , response , sizeof(response) , 0);

			//Checking if response was received
			if(n > 0)
			{

				response[n] = '\0';

				if(!strcmp(response,"error"))
				{
					printf("\nInvalid Command type help to fetch supported commands\n\n");
					continue;
				}
				else
					printf("Response Received from Server\n");

				printf("Response : %s\n",response);
			}
			else
			{

				printf("No Response received from Server\n");

			}
		}

	}


	return 0;

}

