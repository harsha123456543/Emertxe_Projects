/*----------------------------------------------------------------
 * FILE:        server.c
 * AUTHOR:      Harsha S
 * PURPOSE:     Control All Server Operations
 * DATE:        October 26, 2025
 -----------------------------------------------------------------*/

#include <stdio.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netinet/ip.h>
#include <stdlib.h>
#include <string.h>
#include <sys/select.h>
#include <unistd.h>


//Main Function to control all Server Operations
int main()
{

	//Creating a socket
	int sock = socket(AF_INET , SOCK_STREAM , 0);

	struct sockaddr_in sck;
	char ip[33];
	short port;

	sck.sin_family = AF_INET;

        printf("Enter the IP Address : ");
        scanf("%s",ip);

        sck.sin_addr.s_addr = inet_addr(ip);

        printf("Enter the Port Number : ");
        scanf("%hd",&port);

        sck.sin_port = htons(port);

	//Bind socket to IP addrees and Port number
	bind(sock , (const struct sockaddr *)&sck , sizeof(sck));

	printf("\nServer started with IP : %s and port : %d\n",ip,port);

	listen(sock , 10);

	struct sockaddr_in client;
	int size = sizeof(client);

	fd_set read_fd , active_fd;

	FD_ZERO(&read_fd);
	FD_ZERO(&active_fd);

	FD_SET(sock,&active_fd);

	while(1)
	{

		read_fd = active_fd;

		select(1024,&read_fd,NULL,NULL,NULL);

		for(int i = 0 ; i < 1024 ; i++)
		{

			if(FD_ISSET(i,&read_fd))
			{
				//New Connection
				if(i == sock)
				{
					int new_sock = accept(sock ,(struct sockaddr*) &client , &size);

		               		inet_ntop(AF_INET , &client.sin_addr , ip , sizeof(ip));

		               		printf("\nNew Client Connected\nIP : %s\nPort : %d\n",ip,ntohs(client.sin_port));

					FD_SET(new_sock,&active_fd);
				}

				//Message from connected client
				else
				{

					char message[100] , exec[100] , command[50] , arg[50] , output[1024] , header[1024];

					int len = recv(i , message , sizeof(message), 0);

					//Client disconnection
					if(len <= 0)
					{
						close(i);
						FD_CLR(i,&active_fd);

						printf("Client Disconnected\n");
						continue;
					}

					sscanf(message,"%s %s",command,arg);

					//All the supported operations
					if(!strcmp(command,"get-mem"))
					{
						strcpy(header,"\n\tMemory Usage     (PID | MEM % | RSS)\n\t\t\t");
						sprintf(exec,"ps -C %s -o pid,%%mem,rss --no-headers",arg);
					}
					else if(!strcmp(command,"get-cpu-usage"))
					{
						strcpy(header,"\n\tCPU Usage    (PID | CPU %)\n\t\t\t");
						sprintf(exec,"ps -C %s -o pid,%%cpu --no-headers",arg);
					}
					else if(!strcmp(command,"get-ports-used"))
					{
						strcpy(header,"\nOpen ports (PID | User | FD | TYPE | Device | Node | Name)\n\t\t\t");
						sprintf(exec,"lsof -Pan -p $(pgrep -x %s) -i | awk '{print $1.$8,$9}'",arg);
					}
					else if(!strcmp(command,"get-open-fd"))
					{
						memset(header,0,sizeof(header));
						sprintf(exec,"PID=$(pgrep %s | head -n 1); echo 'Open FD Count:' $(ls /proc/$PID/fd | wc -l)",arg);
					}
					else if(!strcmp(command,"kill"))
					{
						memset(header,0,sizeof(header));
						sprintf(exec,"pkill -9 %s && echo \"Process %s killed\"",arg,arg);
					}
					else
					{
						send(i , "error" , 6 , 0);
						continue;
					}


					FILE *fp = popen(exec,"r");

					if(fp == NULL)
					{
						send(i , "error" , 6 , 0);
						continue;
					}

					char tbuffer[1024] = "" , buffer[1024] = "";

					//Construct the reponse and send it back to the client
					while(fgets(output,sizeof(output),fp))
					{
						strncat(tbuffer , output , sizeof(tbuffer) - strlen(tbuffer) - 1);
					}
					pclose(fp);

					if(strlen(tbuffer))
					{
						strcpy(buffer,header);
						strcat(buffer,tbuffer);

						send(i , buffer , strlen(buffer) , 0);
					}
					else
					{
						send(i , "No Such Process running\n" , 24 , 0);
					}
				}
			}
		}
	}

	return 0;
}
