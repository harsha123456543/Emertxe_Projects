/*----------------------------------------------------------------
 * FILE:        client.c
 * AUTHOR:      Harsha S
 * PURPOSE:     Controls Operations of Client
 * DATE:        October 9, 2025
 -----------------------------------------------------------------*/

#include <stdio.h>
#include <stdlib.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <string.h>
#include <sys/select.h>

//Main function to control Operations
int main()
{
	char option[2];

	char username[100] , password[100];

	char login_status[2];

	int family = AF_INET;
	int type = SOCK_STREAM;

	//Create Socket
	int sock = socket(family,type,0);

	struct sockaddr_in sck;

	sck.sin_addr.s_addr = inet_addr("127.0.0.1");
	sck.sin_port = htons(2000);
	sck.sin_family = AF_INET;

	retry:
        printf("\nSelect the option :\n1 Login \n2 Register \n3 Exit\n\n");
        scanf(" %s",option);

	if(option[0] == '3')
	{
		printf("Exiting \n");
		return 0;
	}

	if(option[0] < '1' || option[0] > '3')
	{
		printf("Invalid Input\n");
		goto retry;
	}


        printf("Enter the Username : ");
        scanf(" %[^\n]",username);
        printf("Enter the Password : ");
        scanf(" %[^\n]",password);

	//Connect to the server using the socket
	connect(sock,(struct sockaddr *)&sck,sizeof(sck));

	//Send Client Info
	send(sock,option,sizeof(option),0);
        send(sock,username,sizeof(username),0);
        send(sock,password,sizeof(password),0);

	recv(sock,login_status,sizeof(login_status),0);

	//Login / Register
	if(login_status[0] == '0')
	{
		printf("Successfully Logged in\n\n");
	}
	else if(login_status[0] == '1')
	{
		printf("UserName does not exist\n\n");
		return 0;
	}
	else if(login_status[0] == '2')
	{
		printf("User already exists\n\n");
		return 0;
	}
	else if(login_status[0] == '3')
	{
		printf("Incorrect Password\n\n");
		return 0;
	}
	else if(login_status[0] == '4')
	{
		printf("Succesfully Registered\n\n");
	}

	printf("Type ALL:<message> for Group chat or TO:<user>:<message> for Private chat\n");

	char buffer[1024];

	fd_set read_fd;

	int i = 0;

	//Sending messages to server
	while(1)
	{
		FD_ZERO(&read_fd);
		FD_SET(sock,&read_fd);
		FD_SET(0,&read_fd);

		int max = sock > 0 ? sock : 0;

		select(max+1,&read_fd,NULL,NULL,NULL);

		if(FD_ISSET(0,&read_fd))
		{
			scanf(" %[^\n]",buffer);
			send(sock,buffer,strlen(buffer)+1,0);
		}


		if(FD_ISSET(sock,&read_fd))
		{

			if((i = recv(sock,buffer,sizeof(buffer),0)) <= 0)
			{
				printf("Disconnected from server\n");
				return 0;
			}

			buffer[i] = '\0';

			printf("%s\n",buffer);

		}


	}

	return 0;


}
