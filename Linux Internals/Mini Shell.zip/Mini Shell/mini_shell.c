/*----------------------------------------------------------------
 * FILE:        mini_shell.c
 * AUTHOR:      Harsha S
 * PURPOSE:     Control All the Operations
 * DATE:        October 23, 2025 (Updated)
 -----------------------------------------------------------------*/

#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <sys/wait.h>
#include <signal.h>
#include <stdlib.h>
#include <fcntl.h>

pid_t fg_pid = -1;

//Signal Handler
void sigint_handler(int sig)
{
	if(fg_pid > 0)
	{
		kill(fg_pid,SIGINT);
		printf("\nProcess %d terminated\n",fg_pid);
	}
	else
	{
    		printf("\n>");
    		fflush(stdout);
	}
}

void sigstp_handler(int sig)
{
        if(fg_pid > 0)
        {
                kill(fg_pid,SIGTSTP);
                printf("\nProcess %d stopped\n",fg_pid);
        }
        else
        {
                printf("\n>");
                fflush(stdout);
        }
}

//cd command
void cd(int i , char *arg[100])
{
	if(i == 1)
        {
        	char *home = getenv("HOME");
                if(home == NULL)
                    fprintf(stderr, "cd: HOME not set\n");
                else if(chdir(home) != 0)
                    perror("cd");
        }
        else
	{
                char path[1024] = {0};
                for(int k = 1; k < i; k++)
                {
                    strcat(path, arg[k]);
                    if(k != i - 1) strcat(path, " ");
                }

                if(strcmp(path, "~") == 0)
                {
                    char *home = getenv("HOME");
                    if(home) strcpy(path, home);
        	}

                if(chdir(path) != 0)
                    perror("cd");
	}
}

//redirect operation
void redirect_op(char buffer[] , char * filename)
{

        int fd = open(filename, O_WRONLY | O_CREAT | O_TRUNC, 0644);

        if(fd < 0)
        {
                perror("open");
                return;
        }

        write(fd, buffer, strlen(buffer));
        write(fd, "\n", 1);
	close(fd);


}

//echo command
void echo(int i , char *filename , int redirect , char *arg[100])
{

	char buffer[1024] = {0};

        for(int k = 1; k < i; k++)
        {
               if(strcmp(arg[k], "$$") == 0)
               {
                       char pidbuf[20];
                       sprintf(pidbuf, "%d", getpid());
                       strcat(buffer, pidbuf);
               }
               else
               {
                       strcat(buffer, arg[k]);
               }

               if(k != i - 1) strcat(buffer, " ");
	}

	if(redirect && filename != NULL)
	{

		redirect_op(buffer,filename);

        }
        else
        {
                printf("%s\n", buffer);
        }


}


//Other commands
void commands(char *arg[100] , int redirect , char *filename , int background)
{

        pid_t pid = fork();

	if(pid < 0)
        {
        	perror("fork");
                return;
        }
        else if(pid == 0)
        {
        	if(redirect && filename != NULL)
                {
                	int fd = open(filename, O_WRONLY | O_CREAT | O_TRUNC, 0644);
                    	if(fd < 0)
                    	{
                        	perror("open");
                        	exit(1);
                    	}
                   	dup2(fd, STDOUT_FILENO);
                    	close(fd);
                }

               	execvp(arg[0], arg);
                perror("execvp failed");
                exit(1);
        }
	else
        {
            	if(!background)
		{
                 	fg_pid = pid;
		      	waitpid(pid, NULL, 0);
			fg_pid = -1;
		}
		else
		{
			printf("Process %d running in background\n",pid);
		}
        }
}

//pipe command
void piped(char *input)
{

	char *cmds[10];
    	int n = 0;

  	char *token = strtok(input, "|");
    	while (token != NULL && n < 10)
       	{
		cmds[n++] = token;
        	token = strtok(NULL, "|");
    	}

    	cmds[n] = NULL;

    	int pipefds[2*(n-1)];
    	
    	for (int i = 0; i < n-1; i++)
	{
        	if (pipe(pipefds + i*2) < 0)
		{
            		perror("pipe");
            		exit(1);
        	}
    	}

    	for (int i = 0; i < n; i++)
	{
        	pid_t pid = fork();

		if (pid == 0)
		{
	            	if (i > 0)
                	dup2(pipefds[(i-1)*2], STDIN_FILENO);

            		if (i < n-1)
                		dup2(pipefds[i*2 + 1], STDOUT_FILENO);

            		for (int j = 0; j < 2*(n-1); j++)
                		close(pipefds[j]);

            		char *args[10];
            		char *arg = strtok(cmds[i], " \t\n");
            		int k = 0;

			while (arg != NULL && k < 9) {
		                args[k++] = arg;

			arg = strtok(NULL, " \t\n");
            	}

		args[k] = NULL;

	        execvp(args[0], args);
        	perror("execvp failed");

		exit(1);
        	}
		else if(pid > 0 && i == n - 1)
		{
			fg_pid = pid;
		}
    	}

    	for (int i = 0; i < 2*(n-1); i++)
        	close(pipefds[i]);

    	for (int i = 0; i < n; i++)
        	wait(NULL);

	fg_pid = -1;

}

//Main Function to control all the operations
int main()
{
    	char input[1024];
    	signal(SIGINT , sigint_handler);
	signal(SIGTSTP , sigstp_handler);

    	while(1)
    	{
        	int i = 0, j = 0, redirect = 0 , background = 0 , pipes = 0;
        	char *arg[100], *token, *filename = NULL;

        	printf(">");
        	fflush(stdout);
        	scanf(" %[^\n]", input);

        	if(strcmp(input, "exit") == 0)
        	{
            		return 0;
        	}

		//Parse the input string
		if(strchr(input,'|'))
		{
			piped(input);
			continue;
		}

        	token = strtok(input, " ");

		while(token != NULL)
        	{
            		if(strcmp(token, ">") == 0)
            		{
                		redirect = 1;
            		}
            		else if(!redirect)
            		{
                		arg[i++] = token;
            		}
            		else
            		{
                		filename = token;
            		}
            		token = strtok(NULL, " ");
        	}
        	arg[i] = NULL;

		if(i > 0 && strcmp(arg[i-1],"&") == 0)
		{
			background = 1;
			arg[i-1] = 0;
		}

		//cd command
        	if(strcmp(arg[0], "cd") == 0)
        	{
			cd(i,arg);
		}

		//echo command
        	else if(strcmp(arg[0], "echo") == 0)
        	{
			echo(i,filename,redirect,arg);
		}

		//Other commands
        	else
        	{
			commands(arg,redirect,filename,background);
        	}

    	}

    	return 0;
}

