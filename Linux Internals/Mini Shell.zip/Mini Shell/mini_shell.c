/*----------------------------------------------------------------
 * FILE:        mini_shell.c
 * AUTHOR:      Harsha S
 * PURPOSE:     Control All the Operations
 * DATE:        October 9, 2025
 -----------------------------------------------------------------*/

#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <sys/wait.h>
#include <signal.h>
#include <stdlib.h>
#include <fcntl.h>

//Signal Handler
void handler(int sig)
{
    printf("\n>");
    fflush(stdout);
}

//Main Function to control all the operations
int main()
{
    char input[1024];
    signal(SIGINT, handler);

    while(1)
    {
        int i = 0, j = 0, redirect = 0;
        char *arg[100], *token, *filename = NULL;

        printf(">");
        fflush(stdout);
        scanf(" %[^\n]", input);

        if(strcmp(input, "exit()") == 0)
        {
            printf("Exiting\n");
            return 0;
        }

	//Parse the input string
        token = strtok(input, " ");
        while(token != NULL)
        {
            if(strcmp(token, ">") == 0)
            {
                redirect = 1;
            }
            else if(!redirect)
            {
                arg[i++] = token;
            }
            else
            {
                filename = token;
            }
            token = strtok(NULL, " ");
        }
        arg[i] = NULL;

	//cd command
        if(strcmp(arg[0], "cd") == 0)
        {
            if(i == 1)
            {
                char *home = getenv("HOME");
                if(home == NULL)
                    fprintf(stderr, "cd: HOME not set\n");
                else if(chdir(home) != 0)
                    perror("cd");
            }
            else
            {
                char path[1024] = {0};
                for(int k = 1; k < i; k++)
                {
                    strcat(path, arg[k]);
                    if(k != i - 1) strcat(path, " ");
                }

                if(strcmp(path, "~") == 0)
                {
                    char *home = getenv("HOME");
                    if(home) strcpy(path, home);
                }

                if(chdir(path) != 0)
                    perror("cd");
            }
        }

	//echo command
        else if(strcmp(arg[0], "echo") == 0)
        {
            char buffer[1024] = {0};

            for(int k = 1; k < i; k++)
            {
                if(strcmp(arg[k], "$$") == 0)
                {
                    char pidbuf[20];
                    sprintf(pidbuf, "%d", getpid());
                    strcat(buffer, pidbuf);
                }
                else
                {
                    strcat(buffer, arg[k]);
                }
                if(k != i - 1) strcat(buffer, " ");
            }

		//redirect operation
            if(redirect && filename != NULL)
            {
                int fd = open(filename, O_WRONLY | O_CREAT | O_TRUNC, 0644);
                if(fd < 0)
                {
                    perror("open");
                    continue;
                }
                write(fd, buffer, strlen(buffer));
                write(fd, "\n", 1);
                close(fd);
            }
            else
            {
                printf("%s\n", buffer);
            }
        }

	//Other commands
        else
        {
            pid_t pid = fork();
            if(pid < 0)
            {
                perror("fork");
                continue;
            }
            else if(pid == 0)
            {
                if(redirect && filename != NULL)
                {
                    int fd = open(filename, O_WRONLY | O_CREAT | O_TRUNC, 0644);
                    if(fd < 0)
                    {
                        perror("open");
                        exit(1);
                    }
                    dup2(fd, STDOUT_FILENO);
                    close(fd);
                }

                execvp(arg[0], arg);
                perror("execvp failed");
                exit(1);
            }
            else
            {
                waitpid(pid, NULL, 0);
            }
        }
    }
    return 0;
}

