/*----------------------------------------------------------------
 * FILE:        server.c
 * AUTHOR:      Harsha S
 * PURPOSE:     Control All Server Operations
 * DATE:        October 15, 2025
 -----------------------------------------------------------------*/

#include <stdio.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netinet/ip.h>
#include <unistd.h>
#include <fcntl.h>
#include <stdlib.h>
#include <string.h>

#define MAX_FD 1024

//Main Function controls all the operations
int main()
{

	//Create a socket
	int sock = socket(AF_INET,SOCK_DGRAM,0);

	struct sockaddr_in sck , client;

	sck.sin_family = AF_INET;
	sck.sin_port = htons(4000);
	sck.sin_addr.s_addr = inet_addr("127.0.0.1");

	int size = sizeof(client);

	//Bind the socket to the specific IP Address
	bind(sock,(const struct sockaddr *)&sck,sizeof(sck));

	while(1)
	{
		char filename[100] , buffer[1024] , option[20] , status[20];

		//Read the operation to perform
		recvfrom(sock,option,sizeof(option),0,(struct sockaddr*)&client,&size);

		//Check Connection between Server and Client
		if(!strcmp(option,"Connect"))
		{
			sendto(sock,"Connected",11,0,(const struct sockaddr*)&client,size);
		}

		//Receive File from Client
		else if(!strcmp(option,"Send"))
		{
			int n = 0;

			recvfrom(sock,filename,sizeof(filename),0,(struct sockaddr*)&client,&size);

	                int fd = open(filename, O_CREAT | O_WRONLY | O_TRUNC , 0644);

        	        if(fd < 0)
               		{
                        	perror("open");
                	}

			//Receive file in chunks of 1KB
                	while((n = recvfrom(sock,buffer,sizeof(buffer),0,(struct sockaddr*)&client,&size)) > 0)
			{
				write(fd,buffer,n);

				if(n < 1024) break;
			}

			sendto(sock,"Success",10,0,(const struct sockaddr*)&client,size);

                	close(fd);

		}

		//Send File to Client
		else if(!strcmp(option,"Receive"))
		{

			int n = 0;

                        recvfrom(sock,filename,sizeof(filename),0,(struct sockaddr*)&sck,&size);

			int fd = open(filename, O_RDONLY , 0644);

			if(fd < 0)
			{
				perror("open");

				sendto(sock,"no",3,0,(const struct sockaddr*)&client,size);
			}

	       		sendto(sock,"exist",6,0,(const struct sockaddr*)&client,size);


			//Send file to client in chunks of 1KB
			while((n = read(fd,buffer,sizeof(buffer))) > 0)
			{
				sendto(sock,buffer,n,0,(const struct sockaddr*)&client,size);
			}

			close(fd);
		}

		//Disconnect Client from server
		else if(!strcmp(option,"Disconnect"))
		{

			sendto(sock,"OK",3,0,(const struct sockaddr*)&client,size);

		}

	}

	return 0;

}

