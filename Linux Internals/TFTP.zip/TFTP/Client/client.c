/*----------------------------------------------------------------
 * FILE:        client.c
 * AUTHOR:      Harsha S
 * PURPOSE:     Control All Client operations
 * DATE:        October 15, 2025
 -----------------------------------------------------------------*/

#include <stdio.h>
#include <sys/socket.h>
#include <stdlib.h>
#include <arpa/inet.h>
#include <netinet/ip.h>
#include <sys/select.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>

//Main function to control all operations
int main()
{
	char ip[20];

	//Create a Socket
	int sock = socket(AF_INET,SOCK_DGRAM,0);

	//Read Server IP
	printf("Enter the IP Address : ");
        scanf("%s",ip);

	struct sockaddr_in serv;

	serv.sin_family = AF_INET;
	serv.sin_port = htons(4000);
	serv.sin_addr.s_addr = inet_addr(ip);

	int size = sizeof(serv);

	while(1)
	{
		char filename[100] , buffer[1024] , option[20] , status[20];
		int connected = 0;

		//Read operation to perform
		printf("\n> Connect\n> Send\n> Receive\n> Disconnect\n\n> ");
		scanf(" %[^\n]",option);

		//Connect Option
		if(!strcmp(option,"Connect"))
		{
			sendto(sock,"Connect",10,0,(const struct sockaddr*)&serv,size);

			recvfrom(sock,status,sizeof(status),0,(struct sockaddr*)&serv,&size);

			if(!strcmp(status,"Connected"))
			{
				printf("Connected Successfully\n");
				connected = 1;
			}
			else
			{
				printf("Connection Failed\n");
				return 0;
			}
		}

		//Allow other operations only if connected
		else if(!connected)
		{

			printf("Connect to the Server Before Performing Operations\n");
			continue;

		}

		//Send File operation
		else if(!strcmp(option,"Send"))
		{
			int n = 0;

			sendto(sock,"Send",5,0,(const struct sockaddr *)&serv,size);

			printf("Enter the file name : ");
			scanf(" %[^\n]",filename);

			int fd = open(filename , O_RDONLY , 0);

			if(fd < 0)
			{
				perror("open");
			}

			sendto(sock,filename,strlen(filename)+1,0,(const struct sockaddr*)&serv,size);

			//Send File data in chunks of 1KB
			while((n = read(fd,buffer,sizeof(buffer))) > 0)
			{

				sendto(sock,buffer,n,0,(const struct sockaddr*)&serv,size);

				if(n < 1024) break;
			}

			//Send Status from server
			recvfrom(sock,status,sizeof(status),0,(struct sockaddr*)&serv,&size);

			if(!strcmp(status,"Success"))
			{
				printf("File Transmitted Successfully\n");
			}
			else
			{
				printf("File Transfer Failed\n");
			}

			close(fd);

		}

		//Receive Operation
		else if(!strcmp(option,"Receive"))
		{
			int n = 0;

			sendto(sock,"Receive",8,0,(const struct sockaddr*)&serv,size);

			printf("Enter the file name : ");
			scanf(" %[^\n]",filename);

			//Search for File on server end
			sendto(sock,filename,strlen(filename)+1,0,(const struct sockaddr*)&serv,size);

			recvfrom(sock,status,sizeof(status),0,(struct sockaddr*)&serv,&size);

			if(!strcmp(status,"exist"))
			{
				printf("File Found and recieving Data\n");
			}
			else
			{
				printf("File not Found\n");
				break;
			}

                        int fd = open(filename , O_CREAT | O_WRONLY | O_TRUNC , 0644);

                        if(fd < 0)
                        {
                                perror("open");
                                break;
                        }

			//Write file in chunks of 1KB
			while((n = recvfrom(sock,buffer,sizeof(buffer),0,(struct sockaddr*)&serv,&size)) > 0)
			{

				write(fd,buffer,n);

				if(n < 1024) break;
			}

			close(fd);

		}

		//Disconnect Client from Server
		else if(!strcmp(option,"Disconnect"))
		{

			sendto(sock,"Disconnect",11,0,(const struct sockaddr*)&serv,size);

			recvfrom(sock,status,sizeof(status),0,(struct sockaddr*)&serv,&size);

			if(!strcmp(status,"OK"))
			{
				printf("Disconnected Successfully\n");
				return 0;
			}
			else
			{
				printf("Disconnection Failed\n");
			}

		}

		//Incase of invalid operation
		else
		{

			printf("Invalid Operation\n");

		}

	}

	return 0;
}

